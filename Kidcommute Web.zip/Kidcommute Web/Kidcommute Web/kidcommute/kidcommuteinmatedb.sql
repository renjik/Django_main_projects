/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 5.7.9 : Database - kidcommut
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
USE `kidcommut`;

/*Table structure for table `app_amessage_to_parent` */

DROP TABLE IF EXISTS `app_amessage_to_parent`;

CREATE TABLE `app_amessage_to_parent` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message` varchar(200) NOT NULL,
  `AYAAH_id` bigint(20) NOT NULL,
  `STUDENTS_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_amessage_to_parent_AYAAH_id_aa4134b3` (`AYAAH_id`),
  KEY `app_amessage_to_parent_STUDENTS_id_c780806c` (`STUDENTS_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `app_amessage_to_parent` */

insert  into `app_amessage_to_parent`(`id`,`message`,`AYAAH_id`,`STUDENTS_id`) values 
(1,'heyy',1,1);

/*Table structure for table `app_ayaah` */

DROP TABLE IF EXISTS `app_ayaah`;

CREATE TABLE `app_ayaah` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ayaah_name` varchar(200) NOT NULL,
  `contact_number` varchar(200) NOT NULL,
  `place` varchar(200) NOT NULL,
  `post` varchar(200) NOT NULL,
  `pincode` varchar(200) NOT NULL,
  `district` varchar(200) NOT NULL,
  `LOGIN_id` bigint(20) NOT NULL,
  `photo` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_ayaah_login_id_b058d376` (`LOGIN_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `app_ayaah` */

insert  into `app_ayaah`(`id`,`ayaah_name`,`contact_number`,`place`,`post`,`pincode`,`district`,`LOGIN_id`,`photo`) values 
(1,'ayaahone','3432434345','kochi','kochinagar','676125','Ernaklm',3,'static/ayaah.jpg'),
(2,'ayaahtwo','7306033959','adoor','abc place xyz street','676122','Kollam',5,'static/a2.jpeg');

/*Table structure for table `app_bank` */

DROP TABLE IF EXISTS `app_bank`;

CREATE TABLE `app_bank` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_number` varchar(200) NOT NULL,
  `cvv` varchar(200) NOT NULL,
  `expiry_date` varchar(200) NOT NULL,
  `card_no` varchar(200) NOT NULL,
  `balance` varchar(200) NOT NULL,
  `holder` varchar(200) NOT NULL,
  `STUDENTS_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_bank_STUDENTS_id_afbcdf04` (`STUDENTS_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `app_bank` */

insert  into `app_bank`(`id`,`account_number`,`cvv`,`expiry_date`,`card_no`,`balance`,`holder`,`STUDENTS_id`) values 
(1,'12345678901','123','12/12/23','1234567889','','alfi',1);

/*Table structure for table `app_bus` */

DROP TABLE IF EXISTS `app_bus`;

CREATE TABLE `app_bus` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bus_number` varchar(200) NOT NULL,
  `AYAAH_id` bigint(20) NOT NULL,
  `DRIVER_id` bigint(20) NOT NULL,
  `bus_name` varchar(200) NOT NULL,
  `ROUTE_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_bus_ayaah_id_98222d41` (`AYAAH_id`),
  KEY `app_bus_driver_id_ad013977` (`DRIVER_id`),
  KEY `app_bus_ROUTE_id_cc69f194` (`ROUTE_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `app_bus` */

insert  into `app_bus`(`id`,`bus_number`,`AYAAH_id`,`DRIVER_id`,`bus_name`,`ROUTE_id`) values 
(1,'0001',1,1,'bus1',1),
(2,'0002',2,2,'bus2',2);

/*Table structure for table `app_bus_allocation` */

DROP TABLE IF EXISTS `app_bus_allocation`;

CREATE TABLE `app_bus_allocation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `BUS_id` bigint(20) NOT NULL,
  `ROUTE_POINT_id` bigint(20) NOT NULL,
  `STUDENTS_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_bus_allocation_BUS_id_7e260767` (`BUS_id`),
  KEY `app_bus_allocation_ROUTE_POINT_id_719e3d3a` (`ROUTE_POINT_id`),
  KEY `app_bus_allocation_STUDENTS_id_6d17543a` (`STUDENTS_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `app_bus_allocation` */

insert  into `app_bus_allocation`(`id`,`BUS_id`,`ROUTE_POINT_id`,`STUDENTS_id`) values 
(1,1,3,1);

/*Table structure for table `app_chat` */

DROP TABLE IF EXISTS `app_chat`;

CREATE TABLE `app_chat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message` varchar(225) NOT NULL,
  `date_time` varchar(225) NOT NULL,
  `sender_id` bigint(20) NOT NULL,
  `receiver_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_chat_from_id_id_31ef7bdc` (`sender_id`),
  KEY `app_chat_to_id_id_349411b4` (`receiver_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `app_chat` */

insert  into `app_chat`(`id`,`message`,`date_time`,`sender_id`,`receiver_id`) values 
(1,'hh','',6,3),
(2,'ggggggg','',3,6),
(3,'hii','',6,3),
(4,'hii','',6,3),
(5,'hii','',6,3),
(6,'tg','',6,3),
(7,'yy','12',3,6),
(8,'hii','',6,6),
(9,'fg','',6,6),
(10,'hii','',6,6),
(11,'hh','',6,3),
(12,'heyy renji','',6,3),
(13,'heyy renji','',6,6),
(14,'hii','',3,6),
(15,'heyy morning ','',3,6),
(16,'hello gud morning ','',6,3);

/*Table structure for table `app_checkout` */

DROP TABLE IF EXISTS `app_checkout`;

CREATE TABLE `app_checkout` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `checkin_time` varchar(200) NOT NULL,
  `checkout_time` varchar(200) NOT NULL,
  `date_time` varchar(200) NOT NULL,
  `STUDENTS_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_checkout_students_id_173b6ea4` (`STUDENTS_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `app_checkout` */

insert  into `app_checkout`(`id`,`checkin_time`,`checkout_time`,`date_time`,`STUDENTS_id`) values 
(1,'2024-03-03 00:53:35','2024-03-03 00:53:45.446154','2024-03-03',2);

/*Table structure for table `app_complaints` */

DROP TABLE IF EXISTS `app_complaints`;

CREATE TABLE `app_complaints` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message` varchar(200) NOT NULL,
  `reply` varchar(200) NOT NULL,
  `STUDENTS_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_complaints_students_id_9048d507` (`STUDENTS_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `app_complaints` */

insert  into `app_complaints`(`id`,`message`,`reply`,`STUDENTS_id`) values 
(1,'feel bad','hiii',1);

/*Table structure for table `app_driver` */

DROP TABLE IF EXISTS `app_driver`;

CREATE TABLE `app_driver` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `driver_name` varchar(200) NOT NULL,
  `license_number` varchar(200) NOT NULL,
  `contact_number` varchar(200) NOT NULL,
  `place` varchar(200) NOT NULL,
  `post` varchar(200) NOT NULL,
  `pincode` varchar(200) NOT NULL,
  `district` varchar(200) NOT NULL,
  `LOGIN_id` bigint(20) NOT NULL,
  `photo` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_driver_login_id_1550c494` (`LOGIN_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `app_driver` */

insert  into `app_driver`(`id`,`driver_name`,`license_number`,`contact_number`,`place`,`post`,`pincode`,`district`,`LOGIN_id`,`photo`) values 
(1,'driverone','54356363656','433435435','kochi','abc place xyz street','76777','KANNUR',2,'static/OIP_v8DLMNH.jpeg'),
(2,'drivertwo','454534667','3432434679','kochi','kochin','676125','Ernaklm',4,'static/d2.jpeg');

/*Table structure for table `app_fee` */

DROP TABLE IF EXISTS `app_fee`;

CREATE TABLE `app_fee` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amount` varchar(200) NOT NULL,
  `month` varchar(200) NOT NULL,
  `STUDENTS_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_fee_STUDENTS_id_c3997c50` (`STUDENTS_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `app_fee` */

insert  into `app_fee`(`id`,`amount`,`month`,`STUDENTS_id`) values 
(1,'600','2024-03-30',1);

/*Table structure for table `app_location` */

DROP TABLE IF EXISTS `app_location`;

CREATE TABLE `app_location` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lattitude` varchar(200) NOT NULL,
  `longitude` varchar(200) NOT NULL,
  `place` varchar(200) NOT NULL,
  `BUS_id` bigint(20) NOT NULL,
  `date_time` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_location_BUS_id_1b1b2cf5` (`BUS_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `app_location` */

/*Table structure for table `app_login` */

DROP TABLE IF EXISTS `app_login`;

CREATE TABLE `app_login` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `usertype` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `app_login` */

insert  into `app_login`(`id`,`username`,`password`,`usertype`) values 
(1,'admin','123','admin'),
(2,'d1','123','driver'),
(3,'a1','123','ayaah'),
(4,'d2','123','driver'),
(5,'a2','123','ayaah'),
(6,'Alfi','123','parent'),
(7,'abhin','123','parent');

/*Table structure for table `app_message` */

DROP TABLE IF EXISTS `app_message`;

CREATE TABLE `app_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message` varchar(200) NOT NULL,
  `reply` varchar(200) NOT NULL,
  `DRIVER_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_message_DRIVER_id_fb03a1b5` (`DRIVER_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `app_message` */

insert  into `app_message`(`id`,`message`,`reply`,`DRIVER_id`) values 
(1,'hello ','pending',1);

/*Table structure for table `app_message_to_parent` */

DROP TABLE IF EXISTS `app_message_to_parent`;

CREATE TABLE `app_message_to_parent` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message` varchar(200) NOT NULL,
  `DRIVER_id` bigint(20) NOT NULL,
  `STUDENTS_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_driver_message_DRIVER_id_ea23929e` (`DRIVER_id`),
  KEY `app_message_to_parent_STUDENTS_id_1767ad77` (`STUDENTS_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `app_message_to_parent` */

insert  into `app_message_to_parent`(`id`,`message`,`DRIVER_id`,`STUDENTS_id`) values 
(1,'today will be late by 5 min',1,1);

/*Table structure for table `app_payment` */

DROP TABLE IF EXISTS `app_payment`;

CREATE TABLE `app_payment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amount` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `FEE_id` bigint(20) NOT NULL,
  `STUDENTS_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_payment_FEE_id_6af9f3f5` (`FEE_id`),
  KEY `app_payment_STUDENTS_id_b976444f` (`STUDENTS_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `app_payment` */

/*Table structure for table `app_payment_notification` */

DROP TABLE IF EXISTS `app_payment_notification`;

CREATE TABLE `app_payment_notification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message` varchar(200) NOT NULL,
  `date_time` varchar(200) NOT NULL,
  `STUDENTS_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_payment_notification_students_id_6106f14d` (`STUDENTS_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `app_payment_notification` */

insert  into `app_payment_notification`(`id`,`message`,`date_time`,`STUDENTS_id`) values 
(1,'You have to Bus Fee','2024-03-30',1);

/*Table structure for table `app_route` */

DROP TABLE IF EXISTS `app_route`;

CREATE TABLE `app_route` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `routes` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `app_route` */

insert  into `app_route`(`id`,`routes`) values 
(1,'kaloor to edapally'),
(2,'mg to south');

/*Table structure for table `app_route_point` */

DROP TABLE IF EXISTS `app_route_point`;

CREATE TABLE `app_route_point` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `point_name` varchar(200) NOT NULL,
  `stop_no` varchar(200) NOT NULL,
  `ROUTE_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_route_point_ROUTE_id_846b0b83` (`ROUTE_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `app_route_point` */

insert  into `app_route_point`(`id`,`point_name`,`stop_no`,`ROUTE_id`) values 
(1,'kaloor','01',1),
(2,'JLN stadium','02',1),
(3,'mg','01',2);

/*Table structure for table `app_students` */

DROP TABLE IF EXISTS `app_students`;

CREATE TABLE `app_students` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `student_name` varchar(200) NOT NULL,
  `pickup_point` varchar(200) NOT NULL,
  `student_class` varchar(200) NOT NULL,
  `student_division` varchar(200) NOT NULL,
  `place` varchar(200) NOT NULL,
  `post` varchar(200) NOT NULL,
  `pincode` varchar(200) NOT NULL,
  `district` varchar(200) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `P_LOGIN_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_students_p_login_id_b1759b56` (`P_LOGIN_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `app_students` */

insert  into `app_students`(`id`,`student_name`,`pickup_point`,`student_class`,`student_division`,`place`,`post`,`pincode`,`district`,`photo`,`P_LOGIN_id`) values 
(1,'Alfi','mg01','4','A','Kochi','nagar','123456','Ernaklm','static/1709385202611.png',6),
(2,'abin','03','5','D','Kochu','nagar','123456','Ernklm','static/1709403455818.png',7);

/*Table structure for table `app_vehicle_status` */

DROP TABLE IF EXISTS `app_vehicle_status`;

CREATE TABLE `app_vehicle_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` varchar(200) NOT NULL,
  `date_time` varchar(200) NOT NULL,
  `BUS_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_vehicle_status_BUS_id_906e9cfe` (`BUS_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `app_vehicle_status` */

insert  into `app_vehicle_status`(`id`,`status`,`date_time`,`BUS_id`) values 
(1,'breakdown','2024-03-02 19:45:20.594862',1);

/*Table structure for table `auth_group` */

DROP TABLE IF EXISTS `auth_group`;

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `auth_group` */

/*Table structure for table `auth_group_permissions` */

DROP TABLE IF EXISTS `auth_group_permissions`;

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_group_id_b120cbf9` (`group_id`),
  KEY `auth_group_permissions_permission_id_84c5c92e` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `auth_group_permissions` */

/*Table structure for table `auth_permission` */

DROP TABLE IF EXISTS `auth_permission`;

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  KEY `auth_permission_content_type_id_2f476e4b` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;

/*Data for the table `auth_permission` */

insert  into `auth_permission`(`id`,`name`,`content_type_id`,`codename`) values 
(1,'Can add log entry',1,'add_logentry'),
(2,'Can change log entry',1,'change_logentry'),
(3,'Can delete log entry',1,'delete_logentry'),
(4,'Can view log entry',1,'view_logentry'),
(5,'Can add permission',2,'add_permission'),
(6,'Can change permission',2,'change_permission'),
(7,'Can delete permission',2,'delete_permission'),
(8,'Can view permission',2,'view_permission'),
(9,'Can add group',3,'add_group'),
(10,'Can change group',3,'change_group'),
(11,'Can delete group',3,'delete_group'),
(12,'Can view group',3,'view_group'),
(13,'Can add user',4,'add_user'),
(14,'Can change user',4,'change_user'),
(15,'Can delete user',4,'delete_user'),
(16,'Can view user',4,'view_user'),
(17,'Can add content type',5,'add_contenttype'),
(18,'Can change content type',5,'change_contenttype'),
(19,'Can delete content type',5,'delete_contenttype'),
(20,'Can view content type',5,'view_contenttype'),
(21,'Can add session',6,'add_session'),
(22,'Can change session',6,'change_session'),
(23,'Can delete session',6,'delete_session'),
(24,'Can view session',6,'view_session'),
(25,'Can add ayaah',7,'add_ayaah'),
(26,'Can change ayaah',7,'change_ayaah'),
(27,'Can delete ayaah',7,'delete_ayaah'),
(28,'Can view ayaah',7,'view_ayaah'),
(29,'Can add bus',8,'add_bus'),
(30,'Can change bus',8,'change_bus'),
(31,'Can delete bus',8,'delete_bus'),
(32,'Can view bus',8,'view_bus'),
(33,'Can add students',9,'add_students'),
(34,'Can change students',9,'change_students'),
(35,'Can delete students',9,'delete_students'),
(36,'Can view students',9,'view_students'),
(37,'Can add login',10,'add_login'),
(38,'Can change login',10,'change_login'),
(39,'Can delete login',10,'delete_login'),
(40,'Can view login',10,'view_login'),
(41,'Can add payment_notification',11,'add_payment_notification'),
(42,'Can change payment_notification',11,'change_payment_notification'),
(43,'Can delete payment_notification',11,'delete_payment_notification'),
(44,'Can view payment_notification',11,'view_payment_notification'),
(45,'Can add complaints',12,'add_complaints'),
(46,'Can change complaints',12,'change_complaints'),
(47,'Can delete complaints',12,'delete_complaints'),
(48,'Can view complaints',12,'view_complaints'),
(49,'Can add checkout',13,'add_checkout'),
(50,'Can change checkout',13,'change_checkout'),
(51,'Can delete checkout',13,'delete_checkout'),
(52,'Can view checkout',13,'view_checkout'),
(53,'Can add driver',14,'add_driver'),
(54,'Can change driver',14,'change_driver'),
(55,'Can delete driver',14,'delete_driver'),
(56,'Can view driver',14,'view_driver'),
(57,'Can add fee',15,'add_fee'),
(58,'Can change fee',15,'change_fee'),
(59,'Can delete fee',15,'delete_fee'),
(60,'Can view fee',15,'view_fee'),
(61,'Can add bus_tracking',16,'add_bus_tracking'),
(62,'Can change bus_tracking',16,'change_bus_tracking'),
(63,'Can delete bus_tracking',16,'delete_bus_tracking'),
(64,'Can view bus_tracking',16,'view_bus_tracking'),
(65,'Can add route',17,'add_route'),
(66,'Can change route',17,'change_route'),
(67,'Can delete route',17,'delete_route'),
(68,'Can view route',17,'view_route'),
(69,'Can add route_point',18,'add_route_point'),
(70,'Can change route_point',18,'change_route_point'),
(71,'Can delete route_point',18,'delete_route_point'),
(72,'Can view route_point',18,'view_route_point'),
(73,'Can add bus_allocation',19,'add_bus_allocation'),
(74,'Can change bus_allocation',19,'change_bus_allocation'),
(75,'Can delete bus_allocation',19,'delete_bus_allocation'),
(76,'Can view bus_allocation',19,'view_bus_allocation'),
(77,'Can add driver_message',20,'add_driver_message'),
(78,'Can change driver_message',20,'change_driver_message'),
(79,'Can delete driver_message',20,'delete_driver_message'),
(80,'Can view driver_message',20,'view_driver_message'),
(81,'Can add message',21,'add_message'),
(82,'Can change message',21,'change_message'),
(83,'Can delete message',21,'delete_message'),
(84,'Can view message',21,'view_message'),
(85,'Can add message_to_parent',20,'add_message_to_parent'),
(86,'Can change message_to_parent',20,'change_message_to_parent'),
(87,'Can delete message_to_parent',20,'delete_message_to_parent'),
(88,'Can view message_to_parent',20,'view_message_to_parent'),
(89,'Can add location',22,'add_location'),
(90,'Can change location',22,'change_location'),
(91,'Can delete location',22,'delete_location'),
(92,'Can view location',22,'view_location'),
(93,'Can add amessage_to_parent',23,'add_amessage_to_parent'),
(94,'Can change amessage_to_parent',23,'change_amessage_to_parent'),
(95,'Can delete amessage_to_parent',23,'delete_amessage_to_parent'),
(96,'Can view amessage_to_parent',23,'view_amessage_to_parent'),
(97,'Can add vehicle_status',24,'add_vehicle_status'),
(98,'Can change vehicle_status',24,'change_vehicle_status'),
(99,'Can delete vehicle_status',24,'delete_vehicle_status'),
(100,'Can view vehicle_status',24,'view_vehicle_status'),
(101,'Can add bank',25,'add_bank'),
(102,'Can change bank',25,'change_bank'),
(103,'Can delete bank',25,'delete_bank'),
(104,'Can view bank',25,'view_bank'),
(105,'Can add payment',26,'add_payment'),
(106,'Can change payment',26,'change_payment'),
(107,'Can delete payment',26,'delete_payment'),
(108,'Can view payment',26,'view_payment'),
(109,'Can add chat',27,'add_chat'),
(110,'Can change chat',27,'change_chat'),
(111,'Can delete chat',27,'delete_chat'),
(112,'Can view chat',27,'view_chat');

/*Table structure for table `auth_user` */

DROP TABLE IF EXISTS `auth_user`;

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `auth_user` */

/*Table structure for table `auth_user_groups` */

DROP TABLE IF EXISTS `auth_user_groups`;

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_user_id_6a12ed8b` (`user_id`),
  KEY `auth_user_groups_group_id_97559544` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `auth_user_groups` */

/*Table structure for table `auth_user_user_permissions` */

DROP TABLE IF EXISTS `auth_user_user_permissions`;

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_user_id_a95ead1b` (`user_id`),
  KEY `auth_user_user_permissions_permission_id_1fbb5f2c` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `auth_user_user_permissions` */

/*Table structure for table `django_admin_log` */

DROP TABLE IF EXISTS `django_admin_log`;

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `django_admin_log` */

/*Table structure for table `django_content_type` */

DROP TABLE IF EXISTS `django_content_type`;

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

/*Data for the table `django_content_type` */

insert  into `django_content_type`(`id`,`app_label`,`model`) values 
(1,'admin','logentry'),
(2,'auth','permission'),
(3,'auth','group'),
(4,'auth','user'),
(5,'contenttypes','contenttype'),
(6,'sessions','session'),
(7,'app','ayaah'),
(8,'app','bus'),
(9,'app','students'),
(10,'app','login'),
(11,'app','payment_notification'),
(12,'app','complaints'),
(13,'app','checkout'),
(14,'app','driver'),
(15,'app','fee'),
(16,'app','bus_tracking'),
(17,'app','route'),
(18,'app','route_point'),
(19,'app','bus_allocation'),
(20,'app','message_to_parent'),
(21,'app','message'),
(22,'app','location'),
(23,'app','amessage_to_parent'),
(24,'app','vehicle_status'),
(25,'app','bank'),
(26,'app','payment'),
(27,'app','chat');

/*Table structure for table `django_migrations` */

DROP TABLE IF EXISTS `django_migrations`;

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

/*Data for the table `django_migrations` */

insert  into `django_migrations`(`id`,`app`,`name`,`applied`) values 
(1,'contenttypes','0001_initial','2023-12-21 16:25:34.384080'),
(2,'auth','0001_initial','2023-12-21 16:25:34.550721'),
(3,'admin','0001_initial','2023-12-21 16:25:34.589573'),
(4,'admin','0002_logentry_remove_auto_add','2023-12-21 16:25:34.599574'),
(5,'admin','0003_logentry_add_action_flag_choices','2023-12-21 16:25:34.607974'),
(6,'contenttypes','0002_remove_content_type_name','2023-12-21 16:25:34.635310'),
(7,'auth','0002_alter_permission_name_max_length','2023-12-21 16:25:34.649735'),
(8,'auth','0003_alter_user_email_max_length','2023-12-21 16:25:34.663437'),
(9,'auth','0004_alter_user_username_opts','2023-12-21 16:25:34.671436'),
(10,'auth','0005_alter_user_last_login_null','2023-12-21 16:25:34.686513'),
(11,'auth','0006_require_contenttypes_0002','2023-12-21 16:25:34.689512'),
(12,'auth','0007_alter_validators_add_error_messages','2023-12-21 16:25:34.698517'),
(13,'auth','0008_alter_user_username_max_length','2023-12-21 16:25:34.719422'),
(14,'auth','0009_alter_user_last_name_max_length','2023-12-21 16:25:34.734519'),
(15,'auth','0010_alter_group_name_max_length','2023-12-21 16:25:34.748739'),
(16,'auth','0011_update_proxy_permissions','2023-12-21 16:25:34.756737'),
(17,'auth','0012_alter_user_first_name_max_length','2023-12-21 16:25:34.771742'),
(18,'sessions','0001_initial','2023-12-21 16:25:34.790614'),
(19,'app','0001_initial','2023-12-22 04:06:38.343923'),
(20,'app','0002_auto_20231222_0942','2023-12-22 04:12:45.180024'),
(21,'app','0003_alter_students_photo','2023-12-22 06:14:37.901986'),
(22,'app','0004_bus_bus_name','2023-12-22 06:49:47.099422'),
(23,'app','0005_fee_bus','2023-12-22 11:57:09.156477'),
(24,'app','0006_auto_20231223_0956','2023-12-23 04:26:14.760196'),
(25,'app','0007_fee_student_class','2023-12-23 04:26:58.766498'),
(26,'app','0008_route','2023-12-23 06:37:00.279530'),
(27,'app','0009_route_point','2023-12-23 06:40:04.178407'),
(28,'app','0010_bus_allocation','2023-12-26 05:30:05.440224'),
(29,'app','0011_bus_route','2023-12-26 05:35:15.299290'),
(30,'app','0012_auto_20231226_1256','2023-12-26 07:26:20.782511'),
(31,'app','0013_auto_20231226_1400','2023-12-26 08:30:33.271833'),
(32,'app','0014_remove_complaints_status','2023-12-27 10:12:35.001953'),
(33,'app','0015_auto_20231228_1401','2023-12-28 08:31:40.847161'),
(34,'app','0016_auto_20240102_1706','2024-01-02 11:36:41.061091'),
(35,'app','0017_auto_20240103_0921','2024-01-03 03:52:06.806776'),
(36,'app','0018_driver_message_message','2024-01-03 06:50:51.173525'),
(37,'app','0019_driver_message_ayaah','2024-01-03 06:52:23.223941'),
(38,'app','0020_rename_driver_message_message_to_parent','2024-01-03 06:53:31.287753'),
(39,'app','0021_remove_message_to_parent_ayaah','2024-01-08 04:56:27.970010'),
(40,'app','0022_remove_message_to_parent_reply','2024-01-08 06:46:35.612447'),
(41,'app','0023_remove_message_to_parent_students','2024-01-08 07:02:29.703641'),
(42,'app','0024_message_to_parent_students','2024-01-08 07:07:34.309734'),
(43,'app','0025_auto_20240109_1523','2024-01-09 09:54:01.846588'),
(44,'app','0026_location_date_time','2024-01-09 10:07:47.408250'),
(45,'app','0027_amessage_to_parent','2024-01-10 06:33:58.970957'),
(46,'app','0028_vehicle_status','2024-01-11 03:26:13.382421'),
(47,'app','0029_bank_payment','2024-01-11 03:53:30.583571'),
(48,'app','0030_bank_fee','2024-01-11 14:33:01.036396'),
(49,'app','0031_remove_bank_fee','2024-01-11 14:50:10.649008'),
(50,'app','0032_bank_students','2024-01-11 16:19:08.969801'),
(51,'app','0033_remove_vehicle_status_description','2024-01-15 09:06:02.006747'),
(52,'app','0034_chat','2024-03-02 11:34:08.083981'),
(53,'app','0035_auto_20240303_0308','2024-03-02 21:38:47.885154');

/*Table structure for table `django_session` */

DROP TABLE IF EXISTS `django_session`;

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `django_session` */

insert  into `django_session`(`session_key`,`session_data`,`expire_date`) values 
('6uvq7k889on5vkf8hgyhy573ylrxv1lk','eyJsaWQiOjEsInBpZCI6MX0:1rMnfs:qrK1kB96kpuUo9CSAwlHx1aqa1K1bYNmBHlDFeGXBzg','2024-01-22 11:20:08.407797'),
('r1ast1ry6toi3gh4ec4ba40ata7cisvh','eyJsaWQiOjF9:1rPIhm:Tqfanp31E6sHmogd_60ucw_ouSdKkpBUZJQ1-HjKdKY','2024-01-29 08:52:26.637566'),
('inkj91vzqncyyay8p45i2kmzczlchoc3','eyJsaWQiOjF9:1rQ8Rm:9iiWjZsdm9VLgjQeM6ziCN-N-Ll1H8LaaAN3T7yq2MU','2024-01-31 16:07:22.972320'),
('p87pfxela7925mxjl8oolgctts6vloqf','eyJsaWQiOjF9:1raGRB:8Wm5KCrm4C_TD1knkuDKr_fGhchk_3QRJ67lYpt9d8U','2024-02-28 14:40:37.848080'),
('p682fuimkxv8d6x4yisryvzspckbm8wt','eyJsaWQiOjF9:1rdOaH:_MBGv57nadFwrqoK5l58kP17FODfQUN6KJr_6p228nA','2024-03-08 05:58:57.729158'),
('2h9kmkhus56qofv3r091po044pvt9txc','eyJsaWQiOjF9:1re9sT:VX_zivuw1645_6sfBDsow91ITdeXyfAjxFThwt4A6yI','2024-03-10 08:28:53.666700'),
('k6x71fkjmqf8gffopan8kq1bm0gatnqm','eyJsaWQiOjF9:1rgOnG:YH1eMRhZ1BIN7j5N4WB__hx8IwtfCaKRcD1qJ42Tweg','2024-03-16 12:48:46.146500');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
