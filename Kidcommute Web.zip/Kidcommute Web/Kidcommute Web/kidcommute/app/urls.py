from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.home),
    path('login',views.login_all),
    path('admin_home',views.admin_home),
    path('admin_student_registration',views.admin_student_registration),
    path('parent_home',views.parent_home),
    path('admin_manage_driver',views.admin_manage_driver),
    path('admin_staff_management',views.admin_staff_management),
    path('driver_update/<id>',views.driver_update),
    path('driver_delete/<id>',views.driver_delete),
    path('admin_manage_ayaah',views.admin_manage_ayaah),
    path('ayaah_update/<id>',views.ayaah_update),
    path('ayaah_delete/<id>',views.ayaah_delete),
    path('admin_bus_management',views.admin_bus_management),
    path('admin_fee_management/<id>',views.admin_fee_management),
    path('fee_update/<id>/<id2>',views.fee_update),
    path('fee_delete/<id>/<id2>',views.fee_delete),
    path('admin_manage_route',views.admin_manage_route),
    path('route_update/<id>',views.route_update),
    path('route_delete/<id>',views.route_delete),
    path('admin_manage_route_point/<id>',views.manage_route_point),
    path('route_point_update/<id>',views.route_point_update),
    path('route_point_delete/<id>',views.route_point_delete),
    path('students_update/<id>',views.students_update),
    path('students_delete/<id>',views.students_delete),
    path('admin_student_bus_allocation/<id>',views.student_bus_allocation),
    path('admin_sent_payment_notification/<id>',views.admin_sent_payment_notification),
    path('admin_view_complaints',views.admin_view_complaints),
    path('admin_sent_reply/<id>',views.admin_sent_reply),
    path('admin_change_password',views.admin_change_password),
    path('admin_vehicle_status',views.admin_vehicle_status),
    path('search',views.search),

# ----------------------------------------------------------------------------------------
                        # ANDRIOD

    path('login_and',views.login_and),
    path('usersignup',views.usersignup),
    path('driver_view_profile',views.driver_view_profile),
    path('dmessage_to_admin',views.dmessage_to_admin),
    path('dmessage_to_parent',views.dmessage_to_parent),
    path('driver_change_password',views.driver_change_password), 
    path("vehicle_location",views.vehicle_location),
    path('ayaah_view_profile',views.ayaah_view_profile),
    path('amessage_to_parent',views.amessage_to_parent),
    path('student_view_profile',views.student_view_profile),
    path('view_fees',views.view_fees),
    path('view_amount',views.view_amount),
    path('confirm_payment',views.confirm_payment),
    path('view_reply',views.view_reply),
    path('psend_complaints',views.psend_complaints),
    path('vehicle_status',views.vehicle_status),
    path('d_notification',views.d_notification),
    path('view_vehicle_status',views.view_vehicle_status),
    path('payment_notifications',views.payment_notifications),
    path('checkin',views.checkin),
    path('view_chat_ayaah',views.view_chat_ayaah),
    path('view_chat_parent',views.view_chat_parent),


    path('get_chat/<from_id>/<to_id>',views.get_chat),
    path('chat/<msg>/<from_id>/<to_id>',views.chat),





]