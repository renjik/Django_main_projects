from django.http import JsonResponse
from django.shortcuts import render,redirect,HttpResponse
from itsdangerous import Serializer
from app.models import *
from datetime import datetime

# Create your views here.
def home(request):
    return render(request,'home.html')

def login_all(request):
    if 'submit' in request.POST:
        username = request.POST['username']
        password = request.POST['password']
        if login.objects.filter(username=username,password=password).exists():
            qa = login.objects.get(username=username,password=password)
            request.session['lid']=qa.pk
            if qa.usertype =='admin':
                return HttpResponse(f"<script>alert('welcome Admin');window.location='admin_home'</script>")
        else:
            return HttpResponse(f"<script>alert('invalid username or password');window.location='login'</script>")
    return render(request,'login.html')

def admin_home(request): 
    return render(request,'admin_home.html')

def admin_student_registration(request):
    q1 = students.objects.all()
    if 'submit' in request.POST:
        std_name = request.POST['student_name']
        pickup_point = request.POST['pickup_point']
        std_class = request.POST['student_class']
        std_division = request.POST['student_division']
        place = request.POST['place']
        post = request.POST['post']
        pincode = request.POST['pincode']
        district = request.POST['district']
        photos = request.FILES['img']
        username = request.POST['username']
        password = request.POST['password']

        q = login(username=username,password=password,usertype='parent')
        q.save()

        q1 = students(student_name=std_name,pickup_point=pickup_point,student_class=std_class,student_division=std_division,place=place,post=post,pincode=pincode,district=district,photo=photos,P_LOGIN_id=q.pk)
        q1.save()
        print(q1)
        return HttpResponse(f"<script>window.location='/admin_student_registration'</script>")
    return render(request,'admin_student_registration.html',{'q1':q1})

def students_update(request,id):
    qs = students.objects.get(id=id)
    if 'submit' in request.POST:
            try:  
                std_name = request.POST['student_name']
                pickup_point = request.POST['pickup_point']
                std_class = request.POST['student_class']
                std_division = request.POST['student_division']
                place = request.POST['place']
                post = request.POST['post']
                pincode = request.POST['pincode']
                district = request.POST['district']
                photos = request.FILES['img']
                qs.student_name=std_name
                qs.pickup_point=pickup_point
                qs.student_class=std_class
                qs.student_division=std_division
                qs.place=place
                qs.post=post
                qs.pincode=pincode
                qs.district=district
                qs.photo=photos
                qs.save()
                return HttpResponse(f"<script>alert('Updated');window.location='/admin_student_registration'</script>")
            except:
                std_name = request.POST['student_name']
                pickup_point = request.POST['pickup_point']
                std_class = request.POST['student_class']
                std_division = request.POST['student_division']
                place = request.POST['place']
                post = request.POST['post']
                pincode = request.POST['pincode']
                district = request.POST['district']
                qs.student_name=std_name
                qs.pickup_point=pickup_point
                qs.student_class=std_class
                qs.student_division=std_division
                qs.place=place
                qs.post=post
                qs.pincode=pincode
                qs.district=district
                qs.save()
                return HttpResponse(f"<script>alert('Updated');window.location='/admin_student_registration'</script>")
    
  


    return render(request,'admin_student_registration.html',{'qs':qs})


def search(request):
    if request.method == 'POST':
        search_query = request.POST.get('search', '')  # Get the search query from the POST data
        if search_query:  # If search query is not empty
            matched_students = students.objects.filter(student_class__icontains=search_query)
            return render(request, 'admin_student_registration.html', {'q1': matched_students})
    
    # If there's no search query or if the request method is not POST, return all students
    all_students = students.objects.all()
    return render(request, 'admin_student_registration.html', {'q1': all_students})



   


def students_delete(request,id):
    qd = students.objects.get(id=id)
    qd.delete()
    return HttpResponse(f"<script>alert('Deleted');window.location='/admin_student_registration'</script>")


def parent_home(request):
    return render(request,'parent_home.html')


def admin_staff_management(request):
    return render(request,'admin_staff_management.html')


def admin_manage_driver(request):
    m=driver.objects.all()
    if 'submit' in request.POST:
        driver_name = request.POST['driver_name']
        license_num = request.POST['license_number']
        contact_num = request.POST['contact_number']
        place = request.POST['place']
        post = request.POST['post']
        pincode = request.POST['pincode']
        district = request.POST['district']
        photo = request.FILES['photo']
        username = request.POST['username']
        password = request.POST['password']
        q2 = login(username=username,password=password,usertype='driver')
        q2.save()
        q3 = driver(driver_name=driver_name,license_number=license_num,contact_number=contact_num,place=place,post=post,pincode=pincode,district=district,photo=photo,LOGIN_id = q2.pk)
        q3.save()
        return HttpResponse(f"<script>alert('Driver Registered');window.location='/admin_manage_driver'</script>")
    return render(request,'admin_manage_driver.html',{'m':m})
    


            
def driver_update(request,id):
    q1=driver.objects.get(id=id)
    if 'submit' in request.POST:
            try:
                driver_name = request.POST['driver_name']
                license_num = request.POST['license_number']
                contact_num = request.POST['contact_number']
                place = request.POST['place']
                post = request.POST['post']
                pincode = request.POST['pincode']
                district = request.POST['district']
                photo = request.FILES['photo']
                q1.driver_name=driver_name
                q1.license_number=license_num
                q1.contact_number=contact_num
                q1.place=place
                q1.post=post
                q1.pincode=pincode
                q1.district=district
                q1.photo=photo
                q1.save()
                return HttpResponse(f"<script>alert('Updated');window.location='/admin_manage_driver'</script>")
            except:
                driver_name = request.POST['driver_name']
                license_num = request.POST['license_number']
                contact_num = request.POST['contact_number']
                place = request.POST['place']
                post = request.POST['post']
                pincode = request.POST['pincode']
                district = request.POST['district']
                q1.driver_name=driver_name
                q1.license_number=license_num
                q1.contact_number=contact_num
                q1.place=place
                q1.post=post
                q1.pincode=pincode
                q1.district=district
                q1.save()
                return HttpResponse(f"<script>alert('Updated');window.location='/admin_manage_driver'</script>")
           
    return render(request,'admin_manage_driver.html',{'q1':q1})

def driver_delete(request,id):
    q2 = driver.objects.get(id=id)
    q2.delete()
    return HttpResponse(f"<script>alert('deleted');window.location='/admin_manage_driver'</script>")


def admin_manage_ayaah(request):
    q4=ayaah.objects.all()
    if "submit" in request.POST:
        ayaah_name = request.POST['ayaah_name']
        contact_num = request.POST['contact_number']
        place = request.POST['place']
        post = request.POST['post']
        pincode = request.POST['pincode']
        district = request.POST['district']
        photo =  request.FILES['photo']
        username = request.POST['username']
        password = request.POST['password']
        q3 = login(username=username,password=password,usertype='ayaah')
        q3.save()
        q6 = ayaah(ayaah_name=ayaah_name,contact_number=contact_num,place=place,post=post,pincode=pincode,district=district,photo=photo,LOGIN_id = q3.pk)
        q6.save()
        return HttpResponse(f"<script>alert('Ayaah Registered');window.location='/admin_manage_ayaah'</script>") 
    return render(request,'admin_manage_ayaah.html',{'q4':q4})

def ayaah_update(request,id):
    q1=ayaah.objects.get(id=id)
    if 'submit' in request.POST:
           try:     
                ayaah_name = request.POST['ayaah_name']
                contact_num = request.POST['contact_number']
                place = request.POST['place']
                post = request.POST['post']
                pincode = request.POST['pincode']
                district = request.POST['district']
                photo = request.FILES['photo']
                q1.ayaah_name=ayaah_name
                q1.contact_number=contact_num
                q1.place=place
                q1.post=post
                q1.pincode=pincode
                q1.district=district
                q1.photo=photo
                q1.save()
                return HttpResponse(f"<script>alert('Updated');window.location='/admin_manage_ayaah'</script>")  
           except:
                ayaah_name = request.POST['ayaah_name']
                contact_num = request.POST['contact_number']
                place = request.POST['place']
                post = request.POST['post']
                pincode = request.POST['pincode']
                district = request.POST['district']
                q1.ayaah_name=ayaah_name
                q1.contact_number=contact_num
                q1.place=place
                q1.post=post
                q1.pincode=pincode
                q1.district=district
                q1.save()
                return HttpResponse(f"<script>alert('Updated');window.location='/admin_manage_ayaah'</script>")  
               
    return render(request,'admin_manage_ayaah.html',{'q1':q1})

def ayaah_delete(request,id):
    q2 = ayaah.objects.get(id=id)
    q2.delete()
    return HttpResponse(f"<script>alert('deleted');window.location='/admin_manage_ayaah'</script>")



def admin_bus_management(request):
    ds=driver.objects.all()
    a=ayaah.objects.all()
    r = route.objects.all()
    if 'submit' in request.POST:
        bus_num = request.POST['bus_number']
        bus_name = request.POST['bus_name']
        drivers=request.POST['driver']
        ayaahs = request.POST['ayaah']
        routes = request.POST['route']
        q5 =bus(bus_number=bus_num,bus_name=bus_name,DRIVER_id=drivers,AYAAH_id=ayaahs,ROUTE_id=routes)
        q5.save()
        return HttpResponse("<script>alert('Bus Added');window.location='/admin_bus_management'</script>")
    return render(request,'admin_bus_management.html',{'d':ds,'a':a,'r':r})

def admin_fee_management(request, id):
    q6 = fee.objects.filter(STUDENTS_id=id)
    
    if request.method == 'POST':  # Check if the request method is POST
        month = request.POST['month']
        amount = request.POST['amount']
        
        # Assuming you're passing the student ID in the URL parameter 'id'
        student_id = id
        
        # Create a new fee object with the provided data
        q7 = fee(month=month, amount=amount, STUDENTS_id=student_id)
        q7.save()
        # Add any additional logic after saving the fee object
        return HttpResponse(f"<script>window.location='/admin_fee_management/{id}'</script>")
    
    return render(request, 'admin_fee_management.html', {'q6': q6,'id2':id})


def fee_update(request,id,id2):
    q8 =  fee.objects.get(id=id)
    if 'submit' in request.POST:
        student_class = request.POST['student_class']
        month = request.POST['month']
        amount = request.POST['amount']
        q8.student_class=student_class
        q8.month=month
        q8.amount=amount
        q8.save()
        return HttpResponse(f"<script>window.location='/admin_fee_management/{id2}'</script>")
    return render(request,'admin_fee_management.html',{'q8':q8})

def fee_delete(request,id,id2):
      q9 = fee.objects.get(id=id)
      q9.delete()
      return HttpResponse(f"<script>window.location='/admin_fee_management/{id2}'</script>")


def admin_manage_route(request):
    q10=route.objects.all()
    if 'submit' in request.POST:
        routes = request.POST['routes']
        q9 = route(routes=routes)
        q9.save()
    return render(request,'admin_manage_route.html',{'q10':q10})

def route_update(request,id):
    q11 = route.objects.get(id=id)
    if 'submit' in request.POST:
        routes = request.POST['routes']
        q11.routes=routes
        q11.save()
        return HttpResponse(f"<script>alert('Route Updated');window.location='/admin_manage_route'</script>")
    return render(request,'admin_manage_route.html',{'q11':q11})

def route_delete(request,id):
    q12=route.objects.get(id=id)
    q12.delete()
    return HttpResponse(f"<script>alert('Route deleted');window.location='/admin_manage_route'</script>")

def manage_route_point(request,id):
    q13 = route_point.objects.filter(ROUTE_id=id)
    if 'submit'  in request.POST:
        point_name = request.POST['point_name']
        stop_no = request.POST['stop_no']
        q14 = route_point(ROUTE_id=id,point_name=point_name,stop_no=stop_no)
        q14.save()
        # return HttpResponse(f"<script>alert('Route points added');window.location='/admin_manage_route'</script>")
    return render(request,'admin_manage_route_point.html',{'q13':q13})
    

def route_point_update(request,id):
    q14 = route_point.objects.get(id=id)
    q2 = route_point.objects.all()
    if 'submit' in request.POST:
        point_name = request.POST['point_name']
        stop_no = request.POST['stop_no']
        q14.point_name=point_name
        q14.stop_no=stop_no
        q14.save()
        return HttpResponse(f"<script>alert('Route points Updated');window.location='/admin_manage_route_point/{id}'</script>")
    return render(request,'admin_manage_route_point.html',{'q14':q14,'q2':q2})


def route_point_delete(request,id):
    q15 = route_point.objects.get(id=id)
    q15.delete()
    return HttpResponse(f"<script>alert('Route points Deleted');window.location='/admin_manage_route_point/{id}'</script>")


def student_bus_allocation(request,id):
    q16 = bus.objects.all()
    q17 = route_point.objects.all()
    q18 = route.objects.all()
    # bus_id=request.POST['buses']
    if 'submit' in request.POST:
        buss = request.POST['buses']
        route_points = request.POST['routepoints']
        q19 = bus_allocation(BUS_id=buss,ROUTE_POINT_id=route_points,STUDENTS_id=id)
        q19.save()

    return render(request,'admin_student_bus_allocation.html',{'q16':q16,'q17':q17,'q18':q18})



def admin_sent_payment_notification(request,id):
    q18=payment_notification.objects.all()
    if 'submit' in request.POST:
        message = request.POST['message']
        date = request.POST['date_time']
        q18 = payment_notification(message=message,date_time=date,STUDENTS_id=id)
        q18.save()
    return render(request,'admin_sent_payment_notification.html',{'q18':q18})




def admin_view_complaints(request):
    q20=complaints.objects.all()
    return render(request,'admin_view_complaints.html',{'q20':q20})


def admin_sent_reply(request,id):
    qup=complaints.objects.get(id=id)
    if 'submit' in  request.POST:
        reply=request.POST['reply']
        qup.reply=reply
        qup.save()
        return HttpResponse("<script>alert('Reply Sent');window.location='/admin_view_complaints'</script>") 
    return render(request,'admin_sent_reply.html')

def admin_track_bus(request):
    return render(request,'admin_track_bus.html')


def admin_change_password(request):
    chpd = login.objects.get(id=1 )
    if 'submit' in request.POST:
        cpassword = request.POST['password1']
        password = request.POST['password']
        if chpd.password==cpassword:
            chpd.password=password
            chpd.save()
            return HttpResponse(f"<script>alert('your password have been Changed');window.location='/login'</script>") 
        else:
            return HttpResponse(f"<script>alert('your entered password is wrong');window.location='/admin_change_password'</script>")
    return render(request,'admin_change_password.html')


def admin_vehicle_status(request):
    qv=Vehicle_status.objects.all()
    return render(request,'admin_vehicle_status.html',{'qv':qv})

  


# -----------------------------------------android-----------------------------------------------



def login_and (request):
        username = request.POST['username']
        password = request.POST['password']
        if login.objects.filter(username=username,password=password).exists():
            qa = login.objects.get(username=username,password=password)
            lid=qa.pk 
            if qa.usertype=='driver':
                qc = driver.objects.get(LOGIN_id=lid)
                if qc:
                    uid=qc.pk
                    bu=bus.objects.get(DRIVER_id=uid)
                    if bu:
                        return JsonResponse({ 'status':'ok','lid':lid,'uid':uid,"bid":bu.id,"usertype":"driver"})
                    else:
                         return JsonResponse({ 'status':'no'})
                else:
                    return JsonResponse({ 'status':'no'})
            
            if qa.usertype=='ayaah':
                 qd = ayaah.objects.get(LOGIN_id=lid)
                 if qd:
                        aid=qd.pk
                        bu=bus.objects.get(AYAAH_id=aid)
                        if bu:
                            return JsonResponse({ 'status':'ok','lid':lid,"aid":aid,"bid":bu.id,"usertype":"ayaah"})
                        else:
                            return JsonResponse({ 'status':'no'})
                 else:
                            return JsonResponse({ 'status':'no'})
                 
            if qa.usertype == 'parent':
                qd = students.objects.get(P_LOGIN_id=lid)
                if qd:
                    pid = qd.pk
                    bu=bus_allocation.objects.get(STUDENTS_id=pid)
                    if bu:
                        return JsonResponse({'status':'ok','lid':lid,'pid':pid,'bid':bu.id,"usertype":"parent"}) 
            else:
                    return JsonResponse({ 'status':'no'})
        else:
            return JsonResponse({'status':'no'})
        
        
from django.core.serializers import serialize
 

def usersignup(request):
    student_name = request.POST['student_name']
    pickup_point = request.POST['pickup_point']
    student_class = request.POST['student_class']
    student_division = request.POST['student_division']
    place = request.POST['place']
    print("hello")
    post = request.POST['post']
    pincode = request.POST['pincode']
    district = request.POST['district']
    photo = request.FILES['photo']
    username = request.POST['username']
    password = request.POST['password']
    m = login(username=username,password=password,usertype = 'parent')
    m.save()
    
    m1 = students(student_name=student_name,pickup_point=pickup_point,student_class=student_class,student_division=student_division,place=place,post=post,pincode=pincode,district=district,photo=photo,P_LOGIN_id=m.pk)
    m1.save()

    
    import qrcode
    import uuid
    path = "static/qrcode/" + str(uuid.uuid4()) + ".png"
    img = qrcode.make(str(m1.pk))
    img.save(path)
    
    return JsonResponse({'status':'ok'})

from datetime import date
import time

def checkin(request):
    id=request.POST['sid']
    dates=date.today()
    print(dates)
    times=datetime.now()
    formatted_time = times.strftime("%Y-%m-%d %H:%M:%S")
    q=checkout.objects.filter(STUDENTS_id=id,date_time=dates)
    if q:
        q1=q[0].id
        print(q1)
        ss=checkout.objects.get(id=q1)
        ss.checkout_time=times
        ss.save()
    else:
        se=checkout(checkin_time=formatted_time,STUDENTS_id=id,date_time=dates)
        se.save()
    return JsonResponse({'status':'ok'})



def driver_view_profile(request):
    id=request.POST['uid']  
    if driver.objects.filter(id=id).exists():
        dv = driver.objects.get(id=id)            
        return JsonResponse({'status':'ok','driver_name':dv.driver_name,"license_number":dv.license_number,"contact_number":dv.contact_number,"place":dv.place,"post":dv.post,"pincode":dv.pincode,"district":dv.district,"photo":str(dv.photo)})  
    else:
        return JsonResponse({"status":"no"})

def ayaah_view_profile(request):
    id = request.POST['aid']
    if ayaah.objects.filter(id=id).exists():
        av = ayaah.objects.get(id=id)
        return JsonResponse({'status':'ok','ayaah_name':av.ayaah_name,'contact_number':av.contact_number,'place':av.place,'post':av.post,'pincode':av.pincode,'district':av.district,'photo':str(av.photo)})
    else:
        return JsonResponse({"status":"no"})


def student_view_profile(request):
    id = request.POST['pid']
    if students.objects.filter(id=id).exists():
        sv = students.objects.get(id=id)
        return JsonResponse({'status':'ok','student_name':sv.student_name,'student_class':sv.student_class,'student_division':sv.student_division,'place':sv.place,'post':sv.post,'pincode':sv.pincode,'district':sv.district,'pickup_point':sv.pickup_point,'photo':str(sv.photo)})
    else:
        return JsonResponse({'status':'no'})



def dmessage_to_admin(request):
    message = request.POST['message']
    did = request.POST['did']
    q1 = Message(message=message,reply='pending',DRIVER_id = did)
    q1.save()
    serialized_data = serialize('json',[q1, ])

    return JsonResponse({'q1':serialized_data,"status":'ok'},safe=False)    

def dmessage_to_parent(request):
    message = request.POST['message']
    did = request.POST['did']
    qa=bus.objects.get(DRIVER_id=did)
    if qa:
        try:
            q1=bus_allocation.objects.filter(BUS_id=qa.pk)
            for i in q1:
                q2=message_to_parent(message=message,DRIVER_id=did,STUDENTS_id=i.STUDENTS_id)
                q2.save()
        except:
            print("error")

    serialized_data = serialize('json',[q2])
    return JsonResponse({'q1':serialized_data,"status":'ok'},safe=False)


def amessage_to_parent(request):
    message = request.POST['message']
    ayid = request.POST['aid']
    q1 = bus.objects.get(AYAAH_id=ayid)
    if q1:
        try:
            q2 = bus_allocation.objects.filter(BUS_id=q1.pk)
            for i in q2:
                q3 = Amessage_to_parent(message=message,AYAAH_id=ayid,STUDENTS_id=i.STUDENTS_id)
                q3.save()
        except:
            print("error")
    serialized_data = serialize('json',[q3])
    return JsonResponse({'q2':serialized_data,'status':'ok'},safe=False)



def driver_change_password(request):
    lid = request.POST['lid']
    chpd = login.objects.get(id=lid)
    cpassword = request.POST['current_password']
    password = request.POST['new_password']
    if chpd.password==cpassword:
        chpd.password=password
        chpd.save()
        print(chpd)
        return JsonResponse({'status':'ok'})
    else:
         return JsonResponse({'status':'no'})
    

def vehicle_location(request):
    lattitude = request.POST['lati']
    longitude = request.POST['longi']
    place = request.POST['locaion']
    bid = request.POST['bid']
    import datetime
    date_time = datetime.datetime.now()
    ba = location( lattitude=lattitude,longitude=longitude,place=place,BUS_id=bid,date_time=date_time)
    ba.save()
    serialized_data = serialize('json',[ba,])
    return JsonResponse({'status':'ok'})


def vehicle_status(request):
    status = request.POST['status']
    import datetime
    date_time = datetime.datetime.now()
    bid = request.POST['bid']
    vs = Vehicle_status(status=status,date_time=date_time,BUS_id=bid)
    vs.save()
    serialized_data = serialize('json',[vs,]) 
    return JsonResponse({'status':'ok'})


def view_fees(request):
    id = request.POST['pid']
    vf = fee.objects.get(id=id)
    return JsonResponse({'status':'ok','student_name':vf.STUDENTS.student_name,'student_class':vf.STUDENTS.student_class,'student_division':vf.STUDENTS.student_division,'amount':vf.amount,'month':vf.month})


def view_amount(request):
    id = request.POST['pid']
    va = fee.objects.get(id=id)
    return JsonResponse({'status':'ok',"amount":va.amount})

def confirm_payment(request):
    id = request.POST['pid']
    account_number = request.POST['account_number']
    cvv = request.POST['cvv']
    expiry_date = request.POST['expiry_date']
    card_no = request.POST['card_no']
    holder = request.POST['holder']
    qa = bank(account_number=account_number,cvv=cvv,expiry_date=expiry_date,card_no=card_no,holder=holder,STUDENTS_id=id)
    qa.save()
    serialized_data = serialize('json',[qa,])
    return JsonResponse({'status':'ok'})

def payment_notifications(request):
    id = request.POST['pid']
    nv = payment_notification.objects.filter(STUDENTS_id=id)
    a=[]
    for i in nv:
        a.append({'id':id,'message':i.message,'date_time':i.date_time}) 
    return JsonResponse({'status':'ok','q':a})
    # return JsonResponse({"status":"ok","message":nv.message,"date_time":nv.date_time})

def view_reply(request):
    id = request.POST['pid']
    cv =complaints.objects.filter(STUDENTS_id=id)
    a=[]
    for i in cv:
        a.append({'id':id,'complaints':i.message,'reply':i.reply})
    return JsonResponse({'status':'ok','q':a})



def psend_complaints(request):
    id = request.POST['pid']
    message = request.POST['message']
    pc = complaints(message=message,reply='pending',STUDENTS_id=id)
    pc.save()
    serialized_data =  serialize('json',[pc,])
    return JsonResponse({'status':'ok'})
    

def d_notification(request):
    id = request.POST['pid']
    nv = message_to_parent.objects.filter(STUDENTS_id=id)
    a=[]
    for i in nv:
        a.append({'id':id,'message':i.message}) 
    return JsonResponse({'status':'ok','q':a})


def view_vehicle_status(request):
    id = request.POST['bid']
    vv = Vehicle_status.objects.filter(BUS_id=id)
    a=[]
    for i in vv:
        a.append({'id':id,'status':i.status,'date_time':i.date_time})
    return JsonResponse({'status':'ok','q':a})


def view_chat_ayaah(request):
    id=request.POST['pid']
    q=ayaah.objects.all()
    a=[]
    for i in q:
        a.append({'id':i.LOGIN_id,'ayaah_name':i.ayaah_name})
    return JsonResponse({'status':'ok','q':a})

def get_chat(request,from_id,to_id):
    from django.db.models import Q
    q= Chat.objects.filter(Q(sender_id=from_id, receiver_id=to_id) | Q(sender_id=to_id, receiver_id=from_id))
    a=[]
    for i in q:
        a.append({'sid':i.sender_id,'rid':i.receiver_id,'message':i.message})
    return JsonResponse({'status':'ok','method':'get_chat','q':a})

def chat(request,msg,from_id,to_id):
    pc = Chat(message=msg,sender_id=from_id,receiver_id=to_id)
    pc.save()
    serialized_data =  serialize('json',[pc,])
    return JsonResponse({'method':'chat','status':'ok'})



def view_chat_parent(request):
    id=request.POST['pid']
    q=students.objects.all()
    a=[]
    for i in q:
        a.append({'id':i.P_LOGIN_id,'student_name':i.student_name})
    return JsonResponse({'status':'ok','q':a})