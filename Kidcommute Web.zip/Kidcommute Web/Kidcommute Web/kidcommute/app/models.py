from django.db import models

# Create your models here.
class login(models.Model):
    username = models.CharField(max_length=200)
    password = models.CharField(max_length=200)
    usertype = models.CharField(max_length=200)

class students(models.Model):
    student_name = models.CharField(max_length=200)
    P_LOGIN = models.ForeignKey(login,on_delete = models.CASCADE)
    pickup_point = models.CharField(max_length=200)
    student_class = models.CharField(max_length=200)
    student_division = models.CharField(max_length=200)
    place = models.CharField(max_length=200)
    post = models.CharField(max_length=200)
    pincode = models.CharField(max_length=200)
    district = models.CharField(max_length=200)
    photo = models.ImageField(upload_to='static')


class driver(models.Model):
    LOGIN = models.ForeignKey(login,on_delete = models.CASCADE)
    driver_name = models.CharField(max_length=200)
    license_number = models.CharField(max_length=200)
    contact_number = models.CharField(max_length=200)
    place = models.CharField(max_length=200)
    post = models.CharField(max_length=200)
    pincode = models.CharField(max_length=200)
    district = models.CharField(max_length=200)
    photo = models.ImageField(upload_to='static')


class ayaah(models.Model):
    LOGIN = models.ForeignKey(login,on_delete = models.CASCADE)
    ayaah_name = models.CharField(max_length=200)
    contact_number = models.CharField(max_length=200)
    place = models.CharField(max_length=200)
    post = models.CharField(max_length=200)
    pincode = models.CharField(max_length=200)
    district = models.CharField(max_length=200)
    photo = models.ImageField(upload_to='static')

class route(models.Model):
    routes = models.CharField(max_length=200)


class route_point(models.Model):
    ROUTE = models.ForeignKey(route,on_delete = models.CASCADE)
    point_name = models.CharField(max_length=200)
    stop_no = models.CharField(max_length=200)

class bus(models.Model):
    DRIVER = models.ForeignKey(driver,on_delete =models.CASCADE)
    AYAAH = models.ForeignKey(ayaah,on_delete =models.CASCADE)
    ROUTE = models.ForeignKey(route,on_delete = models.CASCADE)
    bus_number = models.CharField(max_length=200)
    bus_name = models.CharField(max_length=200)



class fee(models.Model):
    STUDENTS = models.ForeignKey(students,on_delete =models.CASCADE)
    month = models.CharField(max_length=200)
    amount = models.CharField(max_length=200)

class payment_notification(models.Model):
    STUDENTS = models.ForeignKey(students,on_delete =models.CASCADE)
    message = models.CharField(max_length=200)
    date_time = models.CharField(max_length=200)

class complaints(models.Model):
    STUDENTS = models.ForeignKey(students,on_delete =models.CASCADE)
    message =models.CharField(max_length=200)
    reply = models.CharField(max_length=200)

class location(models.Model):
    BUS = models.ForeignKey(bus,on_delete =models.CASCADE)
    lattitude = models.CharField(max_length=200)
    longitude = models.CharField(max_length=200)
    place = models.CharField(max_length=200) 
    date_time = models.CharField(max_length=200)
 

class checkout(models.Model):
    STUDENTS = models.ForeignKey(students,on_delete =models.CASCADE)
    checkin_time = models.CharField(max_length=200)
    checkout_time = models.CharField(max_length=200)
    date_time = models.CharField(max_length=200)


class bus_allocation(models.Model):
    STUDENTS = models.ForeignKey(students,on_delete =models.CASCADE)
    BUS = models.ForeignKey(bus,on_delete =models.CASCADE)
    ROUTE_POINT =  models.ForeignKey(route_point,on_delete = models.CASCADE)

class Message(models.Model):
    DRIVER = models.ForeignKey(driver,on_delete =models.CASCADE)
    message = models.CharField(max_length=200)
    reply = models.CharField(max_length=200)

class message_to_parent(models.Model):
    STUDENTS = models.ForeignKey(students,on_delete =models.CASCADE)
    DRIVER = models.ForeignKey(driver,on_delete =models.CASCADE)
    message = models.CharField(max_length=200)


class Amessage_to_parent(models.Model):
    STUDENTS = models.ForeignKey(students,on_delete =models.CASCADE)
    AYAAH = models.ForeignKey(ayaah,on_delete =models.CASCADE)
    message = models.CharField(max_length=200)


class Vehicle_status(models.Model):
    BUS = models.ForeignKey(bus,on_delete =models.CASCADE)
    status = models.CharField(max_length=200)
    date_time = models.CharField(max_length=200)  

class bank(models.Model):
    STUDENTS = models.ForeignKey(students,on_delete =models.CASCADE)
    account_number = models.CharField(max_length=200)
    cvv = models.CharField(max_length=200)
    expiry_date = models.CharField(max_length=200)
    card_no =models.CharField(max_length=200)
    balance = models.CharField(max_length=200)
    holder = models.CharField(max_length=200)


class payment(models.Model):
    FEE = models.ForeignKey(fee,on_delete = models.CASCADE)
    STUDENTS = models.ForeignKey(students,on_delete =models.CASCADE)
    amount = models.CharField(max_length=200)
    date = models.CharField(max_length=200)


class Chat(models.Model):
    sender = models.ForeignKey(login,on_delete=models.CASCADE,related_name="from_id")
    receiver = models.ForeignKey(login,on_delete=models.CASCADE,related_name="to_id")
    message = models.CharField(max_length=225)
    date_time = models.CharField(max_length=225)
