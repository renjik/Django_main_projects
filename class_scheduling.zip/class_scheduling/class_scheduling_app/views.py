from django.http import HttpResponse
from django.shortcuts import render
from class_scheduling_app.models import*
# Create your views here.
def home_pages(request):
    return render(request,'home_page.html')

def log(request):
    if 'sub' in request.POST:
        uname1=request.POST['uname']
        psw1=request.POST['psw']
        try:
            print(uname1,psw1,'nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn')
            qa=login.objects.get(username=uname1,password=psw1)
            print(qa,'ooooooooooooooooooooooooooooooooooooooooo')
            if qa:
                print(qa,'lllllllllllllllllllllllllllllllllllll')
                request.session['lid']=qa.pk
                if qa.usertype=='admin':
                    return HttpResponse("""
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);  color: white; padding: 20px; text-align: center; border-radius: 20px;">
        <img src="https://th.bing.com/th/id/R.1f8cd36463f1ab3e0ad9e7bd10d1cdb6?rik=xY7ZemhLQqJevQ&riu=http%3a%2f%2fwww.omnipay.asia%2fContent%2fimg%2fsuccess-01.png&ehk=dynswNrN3MbNKV4W5kNsY%2bOOuKBgwBNFR7HnCvGU6wQ%3d&risl=&pid=ImgRaw&r=0" alt="Smiley Image" style="width: 100px; height: 100px;border-radius: 20px;">
        <h3 style="color:green;"> Login Successfully ..😄</h3>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = '/admins';
        }, 2000);
    </script>
""")
                
                elif qa.usertype=='teacher':
                    print('hellooooooooo')
                    q1=teachers.objects.get(login_id=request.session['lid'])
                    if q1:
                        request.session['tid']=q1.pk

                        return HttpResponse("<script>alert('teacher login.........');window.location='tchrhome'</script>")
                    
                elif qa.usertype=='student':
                    q2=students.objects.get(login_id=request.session['lid'])
                    if q2:
                        request.session['stid']=q2.pk

                        return HttpResponse("<script>alert('student login.........');window.location='/studentshome'</script>")

        except:
           return HttpResponse("<script>alert('Invalid Cridentials');window.location='logins'</script>") 
    return render(request,'main_login.html')





#################################################################################

#manage departments

def admin(request):
    return render(request,'admin_home.html')



def admin_manage_dep(request):
    q1=departments.objects.all()
    if 'sub' in request.POST:
        dname1=request.POST['dname']
        des1=request.POST['des']
        q2=departments(dep_name=dname1,dep_description=des1)
        q2.save()
    return render(request,'admin_manage_department.html',{'q1':q1})

def department_del(request,id):
    q2=departments.objects.get(department_id=id)
    q2.delete()
    return HttpResponse("<script>alert('deleted.............');window.location='/adminmanagedep'</script>")
    
def department_upd(request,id):
    q3=departments.objects.get(department_id=id)
    if 'update' in request.POST:
        dname1=request.POST['dname']
        des1=request.POST['des']
        q3.dep_name=dname1
        q3.dep_description=des1

        q3.save()
        return HttpResponse("<script>alert('Updated.............');window.location='/adminmanagedep'</script>")
    return render(request,'admin_manage_department.html',{'q3':q3})




#################################################################################

#manage courses

def admin_manage_crs(request):
    q1=courses.objects.all()
    q4=departments.objects.all()
    if 'sub' in request.POST:
        cname1=request.POST['cname']
        dep1=request.POST['dep']
        drn1=request.POST['drn']
        des1=request.POST['des']
        q2=courses(course_name=cname1,duration=drn1,description=des1,department_id=dep1)
        q2.save()
        return HttpResponse("<script>alert('added.............');window.location='/adminmanagec'</script>")
    
    return render(request,'admin_manage_courses.html',{'q1':q1,'q4':q4})

def crs_delete(request,id):
    q2=courses.objects.get(course_id=id)
    q2.delete()
    return HttpResponse("<script>alert('deleted.............');window.location='/adminmanagec'</script>")
    
def crs_update(request,id):
    q3=courses.objects.get(course_id=id)
    q5=departments.objects.all()
    q6=courses.objects.all()
    if 'update' in request.POST:
        cname1=request.POST['cname']
        dep1=request.POST['dep']
        drn1=request.POST['drn']
        des1=request.POST['des']
        q3.course_name=cname1
        q3.department_id=dep1
        q3.duration=drn1
        q3.description=des1
        q3.save()
        return HttpResponse("<script>alert('Updated.............');window.location='/adminmanagec'</script>")
    return render(request,'admin_manage_courses.html',{'q3':q3,'q5':q5,'q6':q6})


#################################################################################

#manage subjects

def admin_manage_sub(request,id):
    q1=subjects.objects.filter(course_id=id)

    if 'sub' in request.POST:
        sname1=request.POST['sname']
        hrs1=request.POST['hrs']
        des1=request.POST['des']    
        q2=subjects(subject_name=sname1,total_hrs=hrs1,sub_description=des1,course_id=id)
        q2.save()
        return HttpResponse(f"<script>alert('saved');window.location='/adminmanagesub/{id}'</script>")
    return render(request,'admin_manage_subject.html',{'q1':q1,'id':id})

def sub_delete(request,id1,id):
    q2=subjects.objects.get(subject_id=id1)
    q2.delete()
    return HttpResponse(f"<script>alert('deleted.............');window.location='/adminmanagesub/{id}'</script>")
    
def sub_update(request,id1,id):
    print(id1)
    print(id)
    q6=subjects.objects.all()
    q3=subjects.objects.get(subject_id=id1)
    q5=courses.objects.all()
    if 'update' in request.POST:
        sname1=request.POST['sname']
        hrs1=request.POST['hrs']
        des1=request.POST['des']
        q3.subject_name=sname1
        q3.total_hrs=hrs1
        q3.sub_description=des1
        q3.save()
        print(id)
        return HttpResponse(f"<script>alert('Updated.............');window.location='/adminmanagesub/{id}'</script>")
    
    return render(request,'admin_manage_subject.html',{'q3':q3,'q6':q6,'q5':q5})



#################################################################################

#manage calender

def admin_manage_cal(request):
    q1=calender.objects.all()
    if 'sub' in request.POST:
        date1=request.POST['date']
        t1=request.POST['title']
        des1=request.POST['des']    
        q2=calender(date=date1,title=t1,description=des1)
        q2.save()
        return HttpResponse("<script>alert('saved....');window.location='/adminmanagecal'</script>")
    return render(request,'admin_mng_calendar.html',{'q1':q1})

def cal_delete(request,id):
    q2=calender.objects.get(calender_id=id)
    q2.delete()
    return HttpResponse("<script>alert('deleted.............');window.location='/adminmanagecal'</script>")
    
def cal_update(request,id):
    # q6=calender.objects.all()
    q3=calender.objects.get(calender_id=id)
    if 'update' in request.POST:
        date1=request.POST['date']
        t1=request.POST['title']
        des1=request.POST['des'] 
        q3.date=date1
        q3.title=t1
        q3.description=des1
        q3.save()
        return HttpResponse("<script>alert('Updated.............');window.location='/adminmanagecal'</script>")
    return render(request,'admin_mng_calendar.html',{'q3':q3})

#################################################################################

#manage tchrs

def tchr_reg(request):
    q3=departments.objects.all()
    q4=subjects.objects.all()
    if 'sub' in request.POST:
        fname1=request.POST['fname']
        lname1=request.POST['lname']
        phn1=request.POST['phn']
        email1=request.POST['email']
        quali1=request.POST['qualification']
        dep1=request.POST['dep']
        subj1=request.POST['subj']
        uname1=request.POST['uname']
        psw1=request.POST['psw']
        q1=login(username=uname1,password=psw1,usertype='teacher')
        q1.save()
        q2=teachers(first_name=fname1,last_name=lname1,phone=phn1,email=email1,qualification=quali1,login_id=q1.pk,department_id=dep1,subject_id=subj1)
        q2.save()
        return HttpResponse("<script>alert('registered...');window.location='/admintchrreg'</script>")

    return render(request,'admin_tchr_reg.html',{'q3':q3,'q4':q4})



def admin_mng_tchr(request):
    q1=teachers.objects.all()
    q3=departments.objects.all()
    q4=subjects.objects.all()
    if 'sub' in request.POST:
        fname1=request.POST['fname']
        lname1=request.POST['lname']
        phn1=request.POST['phn']
        email1=request.POST['email']
        quali1=request.POST['qualification']
        dep1=request.POST['dep']
        subj1=request.POST['subj']
        uname1=request.POST['uname']
        psw1=request.POST['psw']
        ql=login(username=uname1,password=psw1,usertype='teacher')
        ql.save()
        qt=teachers(first_name=fname1,last_name=lname1,phone=phn1,email=email1,qualification=quali1,login_id=ql.pk,department_id=dep1,subject_id=subj1)
        qt.save()
        return HttpResponse("<script>alert('registered...');window.location='/adminmngtchr'</script>")
    return render(request,'admin_manage_tchrs.html',{'q1':q1,'q3':q3,'q4':q4})

def tchr_delete(request,id):
    q2=teachers.objects.get(teacher_id=id)
    q2.delete()
    return HttpResponse("<script>alert('deleted....');window.location='/adminmngtchr'</script>")

def tchr_update(request,id):
    q7=teachers.objects.get(teacher_id=id)
    q6=departments.objects.all()
    q5=subjects.objects.all()

    if 'update' in request.POST:
        fname1=request.POST['fname']
        lname1=request.POST['lname']
        phn1=request.POST['phn']
        email1=request.POST['email']
        quali1=request.POST['qualification']
        dep1=request.POST['dep']
        subj1=request.POST['subj']

        q7.first_name=fname1
        q7.last_name=lname1
        q7.phone=phn1
        q7.email=email1
        q7.qualification=quali1
        q7.department_id=dep1
        q7.subject_id=subj1
        q7.save()
        return HttpResponse("<script>alert('updated....');window.location='/adminmngtchr'</script>")
    
    return render(request,'admin_manage_tchrs.html',{'q7':q7,'q6':q6,'q5':q5})

    
    #################################################################################

#manage students

def stud_reg(request):
    q3=courses.objects.all()
    if 'sub' in request.POST:
        fname1=request.POST['fname']
        lname1=request.POST['lname']
        hname1=request.POST['hname']
        place1=request.POST['place']
        pin1=request.POST['pin']
        phn1=request.POST['phn']
        email1=request.POST['email']
        gender1=request.POST['gender']
        dob1=request.POST['dob']
        crs1=request.POST['crs']
        uname1=request.POST['uname']
        psw1=request.POST['psw']
        q1=login(username=uname1,password=psw1,usertype='student')
        q1.save()
        q2=students(first_name=fname1,last_name=lname1,house_name=hname1,place=place1,pincode=pin1,phone=phn1,email=email1,gender=gender1,dob=dob1,login_id=q1.pk,course_id=crs1)
        q2.save()
        return HttpResponse("<script>alert('registered...');window.location='/adminstudreg'</script>")
    return render(request,'admin_stud_reg.html',{'q3':q3})
    
def admin_mng_stud(request):
    q4=courses.objects.all()
    q5=students.objects.all()
    if 'sub' in request.POST:
        fname1=request.POST['fname']
        lname1=request.POST['lname']
        hname1=request.POST['hname']
        place1=request.POST['place']
        pin1=request.POST['pin']
        phn1=request.POST['phn']
        email1=request.POST['email']
        gender1=request.POST['gender']
        dob1=request.POST['dob']
        crs1=request.POST['crs']
        uname1=request.POST['uname']
        psw1=request.POST['psw']
        ql=login(username=uname1,password=psw1,usertype='student')
        ql.save()
        qs=students(first_name=fname1,last_name=lname1,house_name=hname1,place=place1,pincode=pin1,phone=phn1,email=email1,gender=gender1,dob=dob1,login_id=ql.pk,course_id=crs1)
        qs.save()
        return HttpResponse("<script>alert('registered...');window.location='/adminmngstud'</script>")
    return render(request,'admin_manage_student.html',{'q4':q4,'q5':q5})
   
def stud_delete(request,id):
    q6=students.objects.get(student_id=id)
    q6.delete()
    return HttpResponse("<script>alert('deleted....');window.location='/adminmngstud'</script>")

def stud_update(request,id):
    q7=students.objects.get(student_id=id)
    q8=courses.objects.all()
   

    if 'update' in request.POST:
        fname1=request.POST['fname']
        lname1=request.POST['lname']
        hname1=request.POST['hname']
        place1=request.POST['place']
        pin1=request.POST['pin']
        phn1=request.POST['phn']
        email1=request.POST['email']
        gender1=request.POST['gender']
        dob1=request.POST['dob']
        crs1=request.POST['crs']
       

        q7.first_name=fname1
        q7.last_name=lname1
        q7.house_name=hname1
        q7.place=place1
        q7.pincode=pin1
        q7.phone=phn1
        q7.email=email1
        q7.gender=gender1
        q7.dob=dob1
        q7.course_id=crs1
        q7.save()
        
        return HttpResponse("<script>alert('updated....');window.location='/adminmngstud'</script>")
    
    return render(request,'admin_manage_student.html',{'q7':q7,'q8':q8})

 ###############################################################################################################
    #Generate  schedule(admin)

def generate_schedule(request):
    q1=subjects.objects.all()
    q2=teachers.objects.all()
    if 'sub' in request.POST:
        date1=request.POST['date']
        s_hrs1=request.POST['s_hrs']
        e_hrs1=request.POST['e_hrs']
        subj1=request.POST['subj']
        tchr1=request.POST['tchr']
       
        q2=schedules(date=date1,starting_hr=s_hrs1,ending_hr=e_hrs1,subject_id=subj1,teacher_id=tchr1,teacher_availability_status='pending',schedule_status='pending')
        q2.save()
        return HttpResponse("<script>alert('saved....');window.location='/generateschedule'</script>")

    return render(request,'admin_generate_schedule.html',{'q1':q1,'q2':q2})

#######################################################################################################
    #View class updates(admin)
    

def view_cls_updates(request):
    q1=classupdates.objects.all()
    return render(request,'admin_view_class_updates.html',{'q1':q1})   









#######################################################################################################################################################


#TEACHER MODULE

def tchrs(request):
    return render(request,'tchr_home.html')

def view_time_table(request):
    q1=schedules.objects.filter(teacher_id=request.session['tid'])
    return render(request,'tchr_view_time_table.html',{'q1':q1})

def post_notes(request):
    qa=teachers.objects.get(teacher_id=request.session['tid'])
    sid=qa.subject_id
    if 'sub' in request.POST:
        notes1=request.POST['notes']
        tchr_id=request.session['tid']

        q2=notes(teacher_id=tchr_id,subject_id=sid,notes=notes1)
        q2.save()
        return HttpResponse("<script>alert('saved....');window.location='/postnotes'</script>")
    return render(request,'tchr_post_notes.html')


def view_doubts(request):
    q2=teachers.objects.get(teacher_id=request.session['tid'])
    subid=q2.subject_id
    print(subid)   
    q3=subjects.objects.get(subject_id=subid)
    cid=q3.course_id 
    print(cid)   
    try:
        print('////////////////////////,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,')
        q4=students.objects.filter(course_id=cid)
        print(q4,'////////////////////////////')


        if q4: 
            print('........................................')  
            for i in q4: 
 
                q1=doubts.objects.filter(student_id=i.pk)
                print(q1,'////////////////////////////')
                return render(request,'tchr_view_doubts.html',{'q1':q1})
        else:
            return render(request,'tchr_view_doubts.html')
  
            
    except:
          
        return render(request,'tchr_view_doubts.html')

def answer_dbts(request,id):
    q3=doubts.objects.get(doubts_id=id)
    if 'sub' in request.POST:
        q3.answer='answered'
        q3.save()
        return HttpResponse("<script>alert('Answered....');window.location='/viewdoubts'</script>")


    return render(request,'tchr_answer_doubts.html',{'q3':q3})



def upd_availability(request):
    q1=schedules.objects.filter(teacher_id=request.session['tid'])
    return render(request,'tchr_upd_availability.html',{'q1':q1})

def tchr_accept(request,id):
    q2=schedules.objects.get(schedule_id=id)
    q2.teacher_availability_status='available'
    q2.save()
    return HttpResponse("<script>alert('Available.............');window.location='/tchrupdavailability'</script>")

def tchr_reject(request,id):
    q2=schedules.objects.get(schedule_id=id)
    q2.teacher_availability_status='not available'
    q2.save()
    return HttpResponse("<script>alert(' Not Available.............');window.location='/tchrupdavailability'</script>")


def tchr_acceptschedule(request,id):
    q2=schedules.objects.get(schedule_id=id)
    q2.schedule_status='Accepted'
    q2.save()
    return HttpResponse("<script>alert('Accepted.............');window.location='/tchrupdavailability'</script>")

def tchr_rejectschedule(request,id):
    q2=schedules.objects.get(schedule_id=id)
    q2.schedule_status='Rejected'
    q2.save()
    return HttpResponse("<script>alert(' rejected.............');window.location='/tchrupdavailability'</script>")


def view_other_availability(request):
     q1=schedules.objects.exclude(teacher_id=request.session['tid'])
     return render(request,'tchr_view_other_availability.html',{'q1':q1})


def update_class_details(request):
   q1=schedules.objects.all()
   q2=teachers.objects.get(teacher_id=request.session['tid'])

   if 'sub' in request.POST:
       sch1=request.POST['sch']
       subj1=q2.subject_id
       tchr_id=request.session['tid']
       q3=classupdates(schedule_id=sch1,subject_id=subj1,teacher_id=tchr_id)
       q3.save()
       return HttpResponse("<script>alert('saved.............');window.location='/updateclassdetails'</script>")

   return render(request,'tchr_update_class_details.html',{'q1':q1,'q2':q2})

















#######################################################################################################################################################

#STUDENT MODULE

def student(request):
    return render(request,'students_home.html')


def std_view_timetable(request):
     q2=students.objects.get(student_id=request.session['stid'])
     cid=q2.course_id
     q1=subjects.objects.filter(course_id=cid)
     print(q1)
     try:
        for i in q1:
            q4=schedules.objects.filter(subject_id=i.pk)
            if q4:

                print(q4,'////////////////////////////////////////////////')
                return render(request,'std_view_time_table.html',{'q4':q4})
     except:
        print('mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm')
        return render(request,'std_view_time_table.html')


def view_tchr_availability(request,id):
    q1=schedules.objects.filter(schedule_id=id)
    return render(request,'std_view_tchr_availability.html',{'q1':q1})
    

def view_notes(request):
    qa=students.objects.get(student_id=request.session['stid'])
    cid=qa.course_id
    print(cid)
    q1=subjects.objects.filter(course_id=cid)
    try:

        for i in q1:
            q4=notes.objects.filter(subject_id=i.pk)
            #print(q4)
            return render(request,'std_view_notes.html',{'q4':q4})
    except:
        return render(request,'std_view_notes.html')    

def post_doubts(request):
    
    if'sub' in request.POST:
        std_id=request.session['stid']
        dbts1=request.POST['dbts']
        q1=doubts(student_id=std_id,doubt=dbts1,answer='pending')
        q1.save()
        return HttpResponse("<script>alert('saved....');window.location='/postdoubts'</script>")
    
    return render(request,'std_post_doubts.html')
    

