"""class_scheduling URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from.import views
urlpatterns = [
    path('',views.home_pages),
    path('logins',views.log),
    path('admins',views.admin),
    path('adminmanagedep',views.admin_manage_dep),
    path('dep_del/<id>',views.department_del),
    path('dep_upd/<id>',views.department_upd),
    path('adminmanagec',views.admin_manage_crs),
    path('crs_del/<id>',views.crs_delete),
    path('crs_upd/<id>',views.crs_update),
    path('adminmanagesub/<id>',views.admin_manage_sub),
    path('sub_del/<id1>/<id>',views.sub_delete),
    path('sub_upd/<id1>/<id>',views.sub_update),
    path('adminmanagecal',views.admin_manage_cal),
    path('cal_del/<id>',views.cal_delete),
    path('cal_upd/<id>',views.cal_update),
    path('admintchrreg',views.tchr_reg),
    path('adminmngtchr',views.admin_mng_tchr),
    path('tchr_del/<id>',views.tchr_delete),
    path('tchr_upd/<id>',views.tchr_update),
    path('adminstudreg',views.stud_reg),
    path('adminmngstud',views.admin_mng_stud),
    path('stud_del/<id>',views.stud_delete),
    path('stud_upd/<id>',views.stud_update),
    path('generateschedule',views.generate_schedule),
    path('viewdoubts',views. view_doubts),
    path('answerdbts/<id>',views.answer_dbts),
    path('viewclsupdates',views.view_cls_updates),

    path('tchrhome',views.tchrs),
    path('viewtimetable',views.view_time_table),
    path('postnotes',views.post_notes),
    path('viewdoubts',views.view_doubts),
    path('tchrupdavailability',views.upd_availability),
    path('accept/<id>',views.tchr_accept),
    path('reject/<id>',views.tchr_reject),
    path('tchracceptschedule/<id>',views. tchr_acceptschedule),
    path('tchrrejectschedule/<id>',views. tchr_rejectschedule),
    path('viewotheravailability',views. view_other_availability),
    path('updateclassdetails',views.update_class_details),
   

    path('studentshome',views.student),
    path('stdviewtimetable',views.std_view_timetable),
    path('viewnotes',views.view_notes),
    path('postdoubts',views.post_doubts),
    path('viewtchravailability/<id>',views.view_tchr_availability),
   

    

]
