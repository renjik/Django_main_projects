from django.db import models

# Create your models here.
class login(models.Model):
    login_id=models.AutoField(primary_key=True)
    username=models.CharField(max_length=200)
    password=models.CharField(max_length=100)
    usertype=models.CharField(max_length=200)

class departments(models.Model):
    department_id=models.AutoField(primary_key=True)
    dep_name=models.CharField(max_length=200)
    dep_description=models.CharField(max_length=200)

class courses(models.Model):
    course_id=models.AutoField(primary_key=True)
    department=models.ForeignKey(departments,on_delete=models.CASCADE)
    course_name=models.CharField(max_length=200)
    duration=models.CharField(max_length=100)
    description=models.CharField(max_length=200)

class subjects(models.Model):
    subject_id=models.AutoField(primary_key=True)
    course=models.ForeignKey(courses,on_delete=models.CASCADE)
    subject_name=models.CharField(max_length=200)
    total_hrs=models.CharField(max_length=100)
    sub_description=models.CharField(max_length=200)    

class calender(models.Model):
    calender_id=models.AutoField(primary_key=True)
    date=models.CharField(max_length=200)
    title=models.CharField(max_length=100)
    description=models.CharField(max_length=200)
    
class teachers(models.Model):
    teacher_id=models.AutoField(primary_key=True)
    login=models.ForeignKey(login,on_delete=models.CASCADE)
    department=models.ForeignKey(departments,on_delete=models.CASCADE)
    subject=models.ForeignKey(subjects,on_delete=models.CASCADE)
    first_name=models.CharField(max_length=200)
    last_name=models.CharField(max_length=100)
    phone=models.CharField(max_length=200)    
    email=models.CharField(max_length=100)
    qualification=models.CharField(max_length=200)    

class students(models.Model):
    student_id=models.AutoField(primary_key=True)
    login=models.ForeignKey(login,on_delete=models.CASCADE)
    course=models.ForeignKey(courses,on_delete=models.CASCADE)
    first_name=models.CharField(max_length=200)
    last_name=models.CharField(max_length=100)
    house_name=models.CharField(max_length=200)    
    place=models.CharField(max_length=100)
    pincode=models.CharField(max_length=200)    
    phone=models.CharField(max_length=200)    
    email=models.CharField(max_length=100)
    gender=models.CharField(max_length=200) 
    dob=models.CharField(max_length=200)   

class schedules(models.Model):
    schedule_id=models.AutoField(primary_key=True)
    subject=models.ForeignKey(subjects,on_delete=models.CASCADE)
    teacher=models.ForeignKey(teachers,on_delete=models.CASCADE)
    date=models.CharField(max_length=200)
    starting_hr=models.CharField(max_length=100)
    ending_hr=models.CharField(max_length=200)   
    teacher_availability_status=models.CharField(max_length=200)       
    schedule_status=models.CharField(max_length=200)


class classupdates(models.Model):
    update_id=models.AutoField(primary_key=True)
    schedule=models.ForeignKey(schedules,on_delete=models.CASCADE)
    teacher=models.ForeignKey(teachers,on_delete=models.CASCADE)
    subject=models.ForeignKey(subjects,on_delete=models.CASCADE)


class notes(models.Model):
    note_id=models.AutoField(primary_key=True)
    teacher=models.ForeignKey(teachers,on_delete=models.CASCADE)
    subject=models.ForeignKey(subjects,on_delete=models.CASCADE)
    notes=models.CharField(max_length=200)

class doubts(models.Model):
    doubts_id=models.AutoField(primary_key=True)
    student=models.ForeignKey(students,on_delete=models.CASCADE)
    doubt=models.CharField(max_length=200)
    answer=models.CharField(max_length=200)

    
