from django.apps import AppConfig


class GreenApkConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'green_apk'
