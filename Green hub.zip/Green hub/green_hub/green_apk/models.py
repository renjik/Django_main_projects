from django.db import models

class Tbl_login(models.Model): 
 
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    usertype=models.CharField(max_length=100)
    
class Tbl_staff(models.Model):
    
    LOGIN=models.ForeignKey(Tbl_login,on_delete=models.CASCADE)
    first_name=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)  
    dob=models.CharField(max_length=100)
    gender=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    place=models.CharField(max_length=250)
    pin=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    street=models.CharField(max_length=100)
    city=models.CharField(max_length=100)
    district=models.CharField(max_length=100)
    status=models.CharField(max_length=100)
    
class Tbl_customer(models.Model):
    
    LOGIN=models.ForeignKey(Tbl_login,on_delete=models.CASCADE)
    first_name=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)  
    dob=models.CharField(max_length=100)
    gender=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    place=models.CharField(max_length=250)
    pin=models.CharField(max_length=100)
    post=models.CharField(max_length=7)
    street=models.CharField(max_length=100)
    city=models.CharField(max_length=50)
    district=models.CharField(max_length=100)
 
    status=models.CharField(max_length=15)
    
class Tbl_courier(models.Model):
        
    LOGIN=models.ForeignKey(Tbl_login,on_delete=models.CASCADE)
    name=models.CharField(max_length=100)
    address=models.CharField(max_length=250)
    pin=models.CharField(max_length=7)
    phone=models.CharField(max_length=10)
    status=models.CharField(max_length=15)
        
class Tbl_category(models.Model):
    name=models.CharField(max_length=100)
    description=models.CharField(max_length=500)
    status=models.CharField(max_length=15)
        
class Tbl_subcat(models.Model):
    CATEGORY=models.ForeignKey(Tbl_category,on_delete=models.CASCADE)
    subcat_name=models.CharField(max_length=100)
    description=models.CharField(max_length=500)
    status=models.CharField(max_length=15)
        
class Tbl_item(models.Model):
    SUBCAT=models.ForeignKey(Tbl_subcat,on_delete=models.CASCADE)
    item_name=models.CharField(max_length=100)
    description=models.CharField(max_length=500)
    rate=models.FloatField(float)
    qty=models.CharField(max_length=100)
    image=models.ImageField(upload_to='static/products')
    status=models.CharField(max_length=15) 
        


        
class Tbl_cartmaster(models.Model):    
    CUST=models.ForeignKey(Tbl_customer,on_delete=models.CASCADE)
    tot_amt=models.CharField(max_length=100)
    cartmas_status=models.CharField(max_length=100)
        
class Tbl_cartchild(models.Model):    
    CARTMAS=models.ForeignKey(Tbl_cartmaster,on_delete=models.CASCADE)
    ITEM=models.ForeignKey(Tbl_item,on_delete=models.CASCADE)
    cartcid_qty=models.IntegerField()
  
        


class tbl_stock(models.Model):
    ITEM =models.ForeignKey(Tbl_item,on_delete=models.CASCADE)
    quantity = models.IntegerField()
    

        
class Tbl_card(models.Model):
   
    CUST=models.ForeignKey(Tbl_customer,on_delete=models.CASCADE)
    card_no=models.CharField(max_length=100)
    card_Holder_name=models.CharField(max_length=100)
    cvv=models.CharField(max_length=100)
    Expiry_date = models.CharField(max_length=100)



class Tbl_purmas(models.Model):
    CUST=models.ForeignKey(Tbl_login,on_delete=models.CASCADE)
    total_amt=models.CharField(max_length=100)
    p_status=models.CharField(max_length=15)



class Tbl_order(models.Model):
   
    CARTMAS=models.ForeignKey(Tbl_cartmaster,on_delete=models.CASCADE)
    order_date=models.CharField(max_length=100)
    amount=models.CharField(max_length=100)
    first_name=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    place=models.CharField(max_length=250)
    pin=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    street=models.CharField(max_length=100)
    city=models.CharField(max_length=50)
    district=models.CharField(max_length=100)  
    bill_no=models.CharField(max_length=100)
    status=models.CharField(max_length=100)

class Tbl_orderadmin(models.Model):
   
    PURMAS=models.ForeignKey(Tbl_purmas,on_delete=models.CASCADE)
    order_date=models.CharField(max_length=100)
    amount=models.CharField(max_length=100)
    first_name=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    place=models.CharField(max_length=250)
    pin=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    street=models.CharField(max_length=100)
    city=models.CharField(max_length=50)
    district=models.CharField(max_length=100)  
    bill_no=models.CharField(max_length=100)
    status=models.CharField(max_length=100)



class Tbl_courier_assign(models.Model):  
    COURIER=models.ForeignKey(Tbl_courier,on_delete=models.CASCADE)
    assign_date=models.CharField(max_length=100)
    assign_Status=models.CharField(max_length=100)
    ORDER=models.ForeignKey(Tbl_order,on_delete=models.CASCADE) 
    
class Tbl_delivery(models.Model):
    COURIER_ASSIGN=models.ForeignKey(Tbl_courier_assign,on_delete=models.CASCADE)
    delivery_date=models.CharField(max_length=100)
    CARTMAS=models.CharField(max_length=100)

class Tbl_payment(models.Model):        
     
    ORDER=models.ForeignKey(Tbl_order,on_delete=models.CASCADE)
    CARD=models.ForeignKey(Tbl_card,on_delete=models.CASCADE)
    payment_date=models.CharField(max_length=100)
    payment_status=models.CharField(max_length=100)
        
class Tbl_raw_material(models.Model):       
    CUST=models.ForeignKey(Tbl_customer,on_delete=models.CASCADE)
    CATEGORY=models.ForeignKey(Tbl_category,on_delete=models.CASCADE)
    item_name=models.CharField(max_length=100)
    description=models.CharField(max_length=500)
    rate=models.FloatField(float)
    qty=models.CharField(max_length=100)
    image=models.ImageField(upload_to='static/products')
    status=models.CharField(max_length=15) 


class Tbl_purchild(models.Model):       
    PURMAS=models.ForeignKey(Tbl_purmas,on_delete=models.CASCADE)
    RAW_MATERIAL=models.ForeignKey(Tbl_raw_material,on_delete=models.CASCADE)
    purcid_qty=models.CharField(max_length=100)


class Tbl_custcourier_assign(models.Model):  
    COURIER=models.ForeignKey(Tbl_courier,on_delete=models.CASCADE)
    assign_date=models.CharField(max_length=100)
    assign_Status=models.CharField(max_length=100)
    ORDERADMIN=models.ForeignKey(Tbl_orderadmin,on_delete=models.CASCADE)    