from django.contrib import admin
from django.urls import path
from green_apk import views
urlpatterns = [
    path('', views.homepage),
    path('login', views.login1),
    path('signup', views.signup),
    path('admin_home', views.admin_home),
    path('admin_dashboard', views.admin_dashboard),
    path('admin_manage_staff', views.admin_manage_staff),
    path('admin_manage_courier', views.admin_manage_courier),
    path('ad_update_courier/<id>',views.ad_update_courier),
    path('admin_manage_product', views.admin_manage_product),
    path('adupdate_product/<id>',views.adupdate_product),
    path('admin_activeproduct/<id>',views.admin_activeproduct),
    path('admin_inactiveproduct/<id>',views.admin_inactiveproduct),
    path('admin_manage_category', views.admin_manage_category),
    path('adupdate_category/<id>',views.adupdate_category),
    path('admin_manage_subcat', views.admin_manage_subcat),
    path('adupdate_subcat/<id>',views.adupdate_subcat),
     path('admin_activesubcat/<id>',views.admin_activesubcat),
     path('admin_inactivesubcat/<id>',views.admin_inactivesubcat),
    path('admin_view_staff', views.admin_view_staff),
    path('update_staff/<id>',views.update_staff),
    # path('admin_view_customer', views.admin_view_customer),
     path('admin_activestaff/<id>',views.admin_activestaff),
     path('admin_inactivestaff/<id>',views.admin_inactivestaff),
    path('admin_view_courier', views.admin_view_courier),
    path('admin_view_category', views.admin_view_category),
    path('admin_activecategory/<id>',views.admin_activecategory),
    path('admin_inactivecategory/<id>',views.admin_inactivecategory),
    path('admin_view_subcat', views.admin_view_subcat),
    path('admin_view_product', views.admin_view_product),
    path('admin_order_view',views.admin_order_view),  
    path('admin_assign_courierserviece/<id>', views.admin_assign_courierservice),
    path('admin_sales',views.admin_sales),
    path('admin_view_purchase',views.admin_view_purchase),
    path('admin_view_customer',views.admin_view_customer),
    path('admin_view_customerrawmaterial',views.admin_view_customerrawmaterial),
    path('admin_add_to_cart/<id>',views.admin_add_to_cart),
    path('admin_view_cart',views.admin_view_cart),
    path('admin_customer_order/<id>',views.admin_customer_order),
    path('admin_remove_cart/<id>',views.admin_remove_cart),
    path('addecrement_qty/<id>',views.addecrement_qty),
    path('addincrement_qty/<id>',views.addincrement_qty),
    path('admin_payment/<id>',views.admin_payment),
    path('admin_bill/<id>',views.admin_bill),
    

  
    

    # ---------------------------------------------------------------staff--------
    path('staff_home',views.staff_home),
    path('staff_dashboard', views.staff_dashboard),
    path('staff_manage_courier',views.staff_manage_courier),
    path('staff_view_courier',views.staff_view_courier),
    path('update_courier/<id>',views.update_courier),
    path('staff_manage_category',views.staff_manage_category),
    path('update_category/<id>',views.update_category),
    path('staff_activecategory/<id>',views.staff_activecategory),
    path('staff_inactivecategory/<id>',views.staff_inactivecategory),
    path('staff_view_category',views.staff_view_category),
    path('staff_manage_subcat', views.staff_manage_subcat),
    path('update_subcat/<id>',views.update_subcat),
    path('staff_view_subcat', views.staff_view_subcat),
    path('staff_manage_product', views.staff_manage_product),
    path('update_product/<id>',views.update_product),
    path('staff_view_product', views.staff_view_product),
    path('staff_view_payment_status', views.staff_view_payment_status),
    path('staff_view_purchase',views.staff_view_purchase),
    path('staff_activeproduct/<id>',views.staff_activeproduct),
    path('staff_inactiveproduct/<id>',views.staff_inactiveproduct),
     path('staff_activesubcat/<id>',views.staff_activesubcat),
    path('staff_inactivesubcat/<id>',views.staff_inactivesubcat),



  







    # --------------------------------------------------------------customer----------
    path('customer_home',views.customer_home),
    path('customer_dashboard',views.customer_dashboard),
    path('customer_view_profile',views.customer_view_profile),
    path('customer_view_products',views.customer_view_products),
    path('add_to_cart/<id>',views.add_to_cart),
    path('customer_view_cart',views.customer_view_cart),
    path('decrement_qty/<id>',views.decrement_qty),
    path('increment_qty/<id>',views.increment_qty),
    path('remove_cart/<id>',views.remove_cart),
    path('customer_order/<id>',views.customer_order),
    path('customer_payment/<id>',views.customer_payment),
    path('customer_bill/<id>',views.customer_bill),
    path('login',views.logout),
    path('custbus_dashboard',views.custbus_dashboard),
    path('customer_add_raw_material',views.customer_add_raw_material),
    path('customer_view_raw_material',views.customer_view_raw_material),
    path('update_raw/<id>',views.update_raw),
    path('customer_view_oreder',views.customer_view_oreder),
    path('customer_view_admin_paymnet',views.customer_view_admin_paymnet),
    path('cust_assign_courierservice/<id>',views.cust_assign_courierservice),
    path('cust_activecategory/<id>',views.cust_activecategory),
    path('cust_inactivecategory/<id>',views.cust_activecategory),

   


# ------------------------------courier----------------------
    path('courier_home',views.courier_home),
    path('view_assigned_courier',views.view_assigned_courier),
    path('view_customer_assignoerder',views.view_customer_assignoerder),
    path('update_status/<id>',views.update_status),
    path('custupdate_status/<id>',views.custupdate_status) ,  

    
]   
