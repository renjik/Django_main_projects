from django.http import HttpResponse
from django.shortcuts import render
from green_apk.models import *
from django.db.models import Max

# Create your views here.
def login1(request):
    if 'submit' in request.POST:
        uname=request.POST['username']
        psw=request.POST['psw']
        if Tbl_login.objects.filter(username=uname,password=psw).exists():
           qa=Tbl_login.objects.get(username=uname,password=psw)
           request.session['lid']=qa.pk
           if qa:
             if qa.usertype=='admin':
                return HttpResponse("<script>alert('welcome admin');window.location='/admin_home'</script>")
             elif qa.usertype=='staff':
                q1 = Tbl_staff.objects.get(LOGIN_id=request.session['lid'])
                request.session['sid']=q1.pk
                return HttpResponse("<script>alert('welcome Staff');window.location='/staff_home'</script>")
             elif qa.usertype=='customer':
                q1 = Tbl_customer.objects.get(LOGIN_id=request.session['lid'])
                request.session['cid']=q1.pk
                return HttpResponse("<script>alert('welcome Customer');window.location='/customer_home'</script>")
             elif qa.usertype=='courier':
                q1 = Tbl_courier.objects.get(LOGIN_id=request.session['lid'])
                request.session['cdid']=q1.pk
                return HttpResponse("<script>alert('welcome Courier');window.location='/courier_home'</script>")
        else:
            return HttpResponse("<script>alert('invalid username and password');window.location='/login'</script>")
    return render(request,"login.html")

def signup(request):
    if 'submit' in request.POST:
        username=request.POST['username']
        password=request.POST['password']
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        dob=request.POST['dob']
        gender=request.POST['Gender']
        phone=request.POST['phone']
        place=request.POST['place']
        pin=request.POST['pin']
        post=request.POST['post']
        street=request.POST['street']
        city=request.POST['city']
        district=request.POST['district']
        q=Tbl_login(username=username,password=password,usertype='customer')
        q.save()
        s=Tbl_customer(first_name=first_name,last_name=last_name,dob=dob,gender=gender,phone=phone,place=place,pin=pin,post=post,city=city,street=street,district=district,status='pending',LOGIN_id=q.pk)
        s.save()
        return HttpResponse("<script>alert('Registered');window.location='/signup'</script>")
    return render(request,"signup.html")

def homepage(request):
    return render(request,"homepage.html")

def admin_home(request):
    return render(request,"admin_pages/admin_home.html")

def admin_dashboard(request):
    return render(request,"admin_pages/admin_dashboard.html")

def admin_manage_staff(request):
    if 'submit' in request.POST:
        username=request.POST['username']
        password=request.POST['password']
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        dob=request.POST['dob']
        gender=request.POST['Gender']
        phone=request.POST['phone']
        place=request.POST['place']
        pin=request.POST['pin']
        post=request.POST['post']
        street=request.POST['street']
        city=request.POST['city']
        district=request.POST['district']
        q=Tbl_login(username=username,password=password,usertype='staff')
        q.save()
        s=Tbl_staff(first_name=first_name,last_name=last_name,dob=dob,gender=gender,phone=phone,place=place,pin=pin,post=post,city=city,street=street,district=district,status='pending',LOGIN_id=q.pk)
        s.save()
    return render(request,"admin_pages/admin_manage_staff.html")

def admin_view_staff(request):
    sv=Tbl_staff.objects.all()
    return render(request,"admin_pages/admin_view_staff.html",{'sv':sv})

def update_staff(request,id):
    up=Tbl_staff.objects.get(id=id)
    try:
        if 'submit' in request.POST:
            first_name=request.POST['first_name']
            last_name=request.POST['last_name']
            dob=request.POST['dob']
            gender = request.POST.get('Gender')
            phone=request.POST['phone']
            place=request.POST['place']
            pin=request.POST['pin']
            post=request.POST['post']
            street=request.POST['street']
            city=request.POST['city']
            district=request.POST['district']
            up.first_name=first_name
            up.last_name=last_name
            up.dob=dob
            up.gender=gender
            up.phone=phone
            up.place=place
            up.pin=pin
            up.post=post
            up.street=street
            up.city=city
            up.district=district
            up.save()
            return HttpResponse("<script>alert('Updated');window.location='/admin_view_staff'</script>")
    except:
        if 'submit' in request.POST:
            first_name=request.POST['first_name']
            last_name=request.POST['last_name']
            dob=request.POST['dob']
         
            phone=request.POST['phone']
            place=request.POST['place']
            pin=request.POST['pin']
            post=request.POST['post']
            street=request.POST['street']
            city=request.POST['city']
            district=request.POST['district']
            up.first_name=first_name
            up.last_name=last_name
            up.dob=dob
  
            up.phone=phone
            up.place=place
            up.pin=pin
            up.post=post
            up.street=street
            up.city=city
            up.district=district
            up.save()
            return HttpResponse("<script>alert('Updated');window.location='/admin_view_staff'</script>")

    return render(request,"admin_pages/admin_manage_staff.html",{'up':up})



def admin_activestaff(request,id):
    ob = Tbl_staff.objects.get(id=id)
    ob.status='active'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/admin_view_staff'</script>")

def admin_inactivestaff(request,id):
    ob = Tbl_staff.objects.get(id=id)
    ob.status='inactive'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/admin_view_staff'</script>")




# -------------------------------courier----------------

def admin_manage_courier(request):
    if 'submit' in request.POST:
        username=request.POST['username']
        password=request.POST['password']
        name=request.POST['name']
        address=request.POST['address']
        pin=request.POST['pin']
        phone=request.POST['phone']
        l=Tbl_login(username=username,password=password,usertype='courier')
        l.save()
        c=Tbl_courier(name=name,address=address,pin=pin,phone=phone,status='pending',LOGIN_id=l.pk)
        c.save()
        return HttpResponse("<script>alert('Added');window.location='/admin_manage_courier'</script>")
    return render(request,"admin_pages/admin_manage_courier.html")

def admin_view_courier(request):
    co=Tbl_courier.objects.all()
    return render(request,"admin_pages/admin_view_courier.html",{'co':co})

def ad_update_courier(request,id):
    c=Tbl_courier.objects.get(id=id)
    if 'submit' in request.POST:
        name=request.POST['name']
        address=request.POST['address']
        pin=request.POST['pin']
        phone=request.POST['phone']
        c.name=name
        c.address=address
        c.pin=pin
        c.phone=phone
        c.save()
        return HttpResponse("<script>alert('Updated');window.location='/admin_view_courier'</script>")
    return render(request,"admin_pages/admin_manage_courier.html",{'c':c})
    


# ------------------------------------------------product-------------------------------
def admin_manage_product(request):
    catview = Tbl_subcat.objects.all()
    if 'submit' in request.POST:
        item_name = request.POST['item_name']
        description = request.POST['description']
        rate = request.POST['rate']
        qty = request.POST['qty']
        image=request.FILES['image']
        subcatergory = request.POST['sub_cat']
        q=Tbl_item(item_name=item_name,description=description,rate=rate,qty=qty,image=image,SUBCAT_id=subcatergory,status='pending')
        q.save()
        return HttpResponse("<script>alert('Product Added');window.location='/admin_manage_product'</script>")
    return render(request,"admin_pages/admin_manage_product.html",{'catview':catview})

def admin_view_product(request):
    proview = Tbl_item.objects.all()
    return render(request,"admin_pages/admin_view_product.html",{'proview':proview})

def adupdate_product(request,id):
    p=Tbl_item.objects.get(id=id)
    catview = Tbl_subcat.objects.all()
    try:
       if 'submit' in request.POST:
            item_name = request.POST['item_name']
            description = request.POST['description']
            rate = request.POST['rate']
            qty = request.POST['qty']
            image=request.FILES['image']
            subcatergory = request.POST['sub_cat']
            p.item_name=item_name
            p.description=description
            p.rate=rate
            p.qty=qty
            p.image=image
            p.SUBCAT_id=subcatergory
            p.save
            return HttpResponse("<script>alert('Product Updated');window.location='/admin_view_product'</script>")

    except:
       if 'submit' in request.POST:
            item_name = request.POST['item_name']
            description = request.POST['description']
            rate = request.POST['rate']
            qty = request.POST['qty']
            subcatergory = request.POST['sub_cat']
            p.item_name=item_name
            p.description=description
            p.rate=rate
            p.qty=qty
            p.SUBCAT_id=subcatergory
            p.save
            return HttpResponse("<script>alert('Product Updated');window.location='/admin_view_product'</script>")
    return render(request,"admin_pages/admin_manage_product.html",{'p':p,'catview':catview})


def admin_activeproduct(request,id):
    ob = Tbl_item.objects.get(id=id)
    ob.status='active'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/admin_view_product'</script>")

def admin_inactiveproduct(request,id):
    ob = Tbl_item.objects.get(id=id)
    ob.status='inactive'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/admin_view_product'</script>")

# ---------------------------------------------------category----------------------------------

def admin_manage_category(request):
    if 'submit' in request.POST:
        name = request.POST['name']
        description = request.POST['description']
        m=Tbl_category(name=name,description=description,status='pending')
        m.save()
        return HttpResponse("<script>alert('Catergory Added');window.location='/admin_manage_category'</script>")
    return render(request,"admin_pages/admin_manage_category.html")

def admin_view_category(request):
    q2=Tbl_category.objects.all()
    return render(request,"admin_pages/admin_view_category.html",{'q2':q2})

def adupdate_category(request,id):
    q=Tbl_category.objects.get(id=id)
    if 'submit' in request.POST:
        name = request.POST['name']
        description = request.POST['description']
        q.name=name
        q.description=description
        q.save()
        return HttpResponse("<script>alert('updated');window.location='/admin_view_category'</script>")
    return render(request,"admin_pages/admin_manage_category.html",{'q':q})

def admin_activecategory(request,id):
    ob = Tbl_category.objects.get(id=id)
    ob.status='active'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/admin_view_category'</script>") 

def admin_inactivecategory(request,id):
    ob = Tbl_category.objects.get(id=id)
    ob.status='inactive'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/admin_view_category'</script>")

# ------------------------------------subcategory-------------------------------------

def admin_manage_subcat(request):
    cat=Tbl_category.objects.all()
    if 'submit' in request.POST:
        subcat_name = request.POST['subcat_name']
        description = request.POST['description']
        category= request.POST['category']
        m=Tbl_subcat(subcat_name=subcat_name,description=description,status='pending',CATEGORY_id=category)
        m.save()
        return HttpResponse("<script>alert('Subcategory Added');window.location='/admin_manage_subcat'</script>")
    return render(request,"admin_pages/admin_manage_subcat.html",{'cat':cat})

def admin_view_subcat(request):
    subcat=Tbl_subcat.objects.all()
    return render(request,"admin_pages/admin_view_subcat.html",{'subcat':subcat})

def adupdate_subcat(request,id):
    subc=Tbl_subcat.objects.get(id=id)
    catview = Tbl_category.objects.all()
    try:
        if 'submit' in request.POST:
            subcat_name = request.POST['subcat_name']
            description = request.POST['description']
            subc.subcat_name=subcat_name
            subc.description=description
            subc.save()
            return HttpResponse("<script>alert('updated');window.location='/admin_view_subcat'</script>")
    except:
        if 'submit' in request.POST:
            subcat_name = request.POST['subcat_name']
            description = request.POST['description']
            category= request.POST['category']
            subc.subcat_name=subcat_name
            subc.description=description
            subc.CATEGORY_id=category
            subc.save()
            return HttpResponse("<script>alert('updated');window.location='/admin_view_subcat'</script>")
    return render(request,"admin_pages/admin_manage_subcat.html",{'subc':subc,'catview':catview})

def admin_activesubcat(request,id):
    ob = Tbl_subcat.objects.get(id=id)
    ob.status='active'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/admin_view_subcat'</script>")

def admin_inactivesubcat(request,id):
    ob = Tbl_subcat.objects.get(id=id)
    ob.status='inactive'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/admin_view_subcat'</script>")






def admin_order_view(request):
    q=Tbl_order.objects.all()
    return render(request,'admin_pages/admin_order_view.html',{'q':q})



def admin_assign_courierservice(request, id):
    q = Tbl_courier.objects.all()
    if 'submit' in request.POST:
        courier_id = request.POST['courier']
        # Assuming Tbl_courier_assign is a model, create an instance and save it
        assign_instance = Tbl_courier_assign(assign_date=datetime.datetime.now(), assign_Status='pending', ORDER_id=id, COURIER_id=courier_id)
        assign_instance.save()
        # Update the status of Tbl_order instance
        order_instance = Tbl_order.objects.get(id=id)
        order_instance.status = 'assigned'
        order_instance.save()
        return HttpResponse("<script>alert('assigned');window.location='/admin_order_view'</script>")
    return render(request,"admin_pages/admin_assign_courierserviece.html",{'q':q})

def admin_sales(request):
    q=Tbl_order.objects.all()
    return render(request,'admin_pages/admin_sales.html',{'q':q})


def admin_view_customer(request):
    q=Tbl_customer.objects.all()
    return render(request,'admin_pages/admin_view_customer.html',{'q':q})



def admin_view_customerrawmaterial(request):
    sv=Tbl_category.objects.all()
    vv=Tbl_raw_material.objects.all()
    return render(request,'admin_pages/admin_view_customerrawmaterial.html',{'sv':sv,'vv':vv})


def admin_add_to_cart(request, id):
    q = Tbl_raw_material.objects.get(id=id)
    amount = q.rate 
    
    if Tbl_purmas.objects.filter(CUST_id=request.session['cid'], p_status='pending').exists():
        pur_master = Tbl_purmas.objects.get(CUST_id=request.session['cid'], p_status='pending')
        if Tbl_purchild.objects.filter(PURMAS_id=pur_master.pk, RAW_MATERIAL_id=id).exists():
            # If the item already exists in the cart, increment its quantity
            pur_child = Tbl_purchild.objects.get(PURMAS_id=pur_master.pk, RAW_MATERIAL_id=id)
           # Assuming pur_child.purcid_qty is a string, you need to convert it to an integer
            pur_child.purcid_qty = int(pur_child.purcid_qty) + 1

            pur_child.save()
        else:
            # If the item is not in the cart, create a new entry
            pur_child = Tbl_purchild(purcid_qty=1, PURMAS_id=pur_master.pk, RAW_MATERIAL_id=id)
            pur_child.save()
    
            pur_master.total_amt = str(float(pur_master.total_amt) + amount)
            pur_master.save()

        return HttpResponse("<script>alert('success');window.location='/admin_view_cart';</script>")
    else:
        pur_master = Tbl_purmas(total_amt=amount, p_status='pending', CUST_id=request.session['cid'])
        pur_master.save()
        pur_child = Tbl_purchild(purcid_qty=1, PURMAS_id=pur_master.pk, RAW_MATERIAL_id=id)
        pur_child.save()
        return HttpResponse("<script>alert('success');window.location='/admin_view_cart'</script>")
    
def admin_view_cart(request):
    if Tbl_purchild.objects.filter(PURMAS__CUST_id=request.session.get('cid'), PURMAS__p_status='pending').exists():
        q = Tbl_purchild.objects.filter(PURMAS__CUST_id=request.session.get('cid'),PURMAS__p_status='pending')
        m = Tbl_purmas.objects.get(CUST_id=request.session.get('cid'), p_status='pending')
        return render(request, 'admin_pages/admin_view_cart.html', {'q': q,'m': m}) 
    else:
        return HttpResponse("<script>alert('Cart is empty');window.location='/admin_home';</script>")
    
def admin_remove_cart(request,id):
    q = Tbl_purchild.objects.get(id=id)
    amount = q.RAW_MATERIAL.rate
    rid = q.PURMAS_id
    pur_master = Tbl_purmas.objects.get(id=rid)
    tamount = int(q.RAW_MATERIAL.rate) * int(q.purcid_qty)
    if int(q.purcid_qty) > 1:
        q.purcid_qty = str(int(q.purcid_qty) - 1)
        q.save()
    else:
        q.delete()
    pur_master.total_amt = max(0, float(pur_master.total_amt) - float(amount))
    pur_master.save()
    return HttpResponse("<script>alert('removed');window.location='/admin_view_cart'</script>")



def addincrement_qty(request,id):
    
    q2 = Tbl_purchild.objects.get(id=id)
    q2.purcid_qty = str(int(q2.purcid_qty) + 1)
    q2.save()
    q3 = Tbl_purmas.objects.get(id=q2.PURMAS_id)
    q3.total_amt = str(float(q3.total_amt) + float(q2.RAW_MATERIAL.rate))
    q3.save()
    
    return HttpResponse("<script>alert('Quantity added successfully.');window.location='/admin_view_cart'</script>")


def addecrement_qty(request,id):
    q2 = Tbl_purchild.objects.get(id=id)
    pur_qty = int(q2.purcid_qty)
    if pur_qty > 1:
        q2.purcid_qty = str(pur_qty - 1)
        q2.save()
    else:
        return HttpResponse("<script>alert('Quantity must be a minimum of 1.');window.location='/admin_view_cart'</script>")
    return HttpResponse("<script>alert('Quantity removed successfully.');window.location='/admin_view_cart';</script>")

import datetime
def admin_customer_order(request, id):
    q = Tbl_purmas.objects.get(id=id)
    amount = q.total_amt
    q.p_status='ordered'
    q.save()

    if 'submit' in request.POST:
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        phone = request.POST['phone']
        place = request.POST['place']
        pin = request.POST['pin']
        post = request.POST['post']
        street = request.POST['street']
        city = request.POST['city']
        district = request.POST['district']
      
        

        latest_bill_no = Tbl_orderadmin.objects.aggregate(max_bill_no=Max('bill_no'))['max_bill_no']


        if latest_bill_no is None:
            latest_bill_no = 1000


        new_bill_no = int(latest_bill_no) + 1
        
      
        q = Tbl_orderadmin(
            first_name=first_name, last_name=last_name, phone=phone, pin=pin, post=post,place=place, street=street,
            city=city, district=district,status='pending', order_date=datetime.datetime.now(),
            amount=amount, bill_no=new_bill_no,PURMAS_id=id
        )
        q.save()
        id2=q.pk
        return HttpResponse(f"<script>alert('ordered');window.location='/admin_payment/{id2}'</script>") 
    return render(request, 'admin_pages/admin_order.html')

def admin_payment(request, id):
    s=Tbl_orderadmin.objects.get(id=id)
    f = None  
    if Tbl_card.objects.filter(CUST_id=request.session['cid']).exists():
     
        f = Tbl_card.objects.filter(CUST_id=request.session['cid']).latest('id')

    if 'submit' in request.POST:
        dd=id
        cardno = request.POST.get('cardno')
        card_Holder_name = request.POST.get('holdername')
        Expire_Date = request.POST.get('expdate')
        cvv=request.POST.get('cvv')

        
 
        f = Tbl_card(card_no=cardno, card_Holder_name=card_Holder_name, Expiry_date=Expire_Date, CUST_id=15000,cvv=cvv)
        f.save()
       
        qi = Tbl_payment(payment_date=datetime.datetime.now(), payment_status='payment successful by admin', CARD_id=f.pk, ORDER_id=id)
        qi.save()
        return HttpResponse(f"<script>alert('payment successful');window.location='/admin_bill/{dd}'</script>")
         
    return render(request, 'admin_pages/admin_payment.html', {'f': f,'s':s})

def admin_bill(request,id):
    q=Tbl_orderadmin.objects.get(id=id)
    qt=Tbl_payment.objects.get(ORDER_id=id)
    qi=Tbl_purchild.objects.filter(PURMAS_id=q.PURMAS_id)
    return render(request,'admin_pages/admin_bill.html',{'q':q,'qi':qi,'qt':qt})


def admin_view_purchase(request):
    q=Tbl_order.objects.all()
    return render(request,'admin_pages/admin_view_purchase.html',{'q':q})




# ---------------------------------------------------------------------staff----------------------------------- 
# ---------------------------------------------------------------------------------------------------------------

def staff_home(request):
    return render(request,"staff_pages/staff_home.html")


def staff_dashboard(request):
    return render(request,"staff_pages/staff_dashboard.html")


def staff_manage_courier(request):
    if 'submit' in request.POST:
        username=request.POST['username']
        password=request.POST['password']
        name=request.POST['name']
        address=request.POST['address']
        pin=request.POST['pin']
        phone=request.POST['phone']
        l=Tbl_login(username=username,password=password,usertype='courier')
        l.save()
        c=Tbl_courier(name=name,address=address,pin=pin,phone=phone,status='pending',LOGIN_id=l.pk)
        c.save()
        return HttpResponse("<script>alert('Added');window.location='/staff_manage_courier'</script>")
    return render(request,"staff_pages/staff_manage_courier.html")

def staff_view_courier(request):
    co=Tbl_courier.objects.all()
    return render(request,"staff_pages/staff_view_courier.html",{'co':co})

def update_courier(request,id):
    c=Tbl_courier.objects.get(id=id)
    if 'submit' in request.POST:
        name=request.POST['name']
        address=request.POST['address']
        pin=request.POST['pin']
        phone=request.POST['phone']
        c.name=name
        c.address=address
        c.pin=pin
        c.phone=phone
        c.save()
        return HttpResponse("<script>alert('Updated');window.location='/staff_view_courier'</script>")
    return render(request,"staff_pages/staff_manage_courier.html",{'c':c})



def staff_manage_category(request):
    if 'submit' in request.POST:
        name = request.POST['name']
        description = request.POST['description']
        m=Tbl_category(name=name,description=description,status='pending')
        m.save()
        return HttpResponse("<script>alert('Catergory Added');window.location='/staff_manage_category'</script>")
    return render(request,"staff_pages/staff_manage_category.html")

def staff_view_category(request):
    q2=Tbl_category.objects.all()
    return render(request,"staff_pages/staff_view_category.html",{'q2':q2})

def update_category(request,id):
    q=Tbl_category.objects.get(id=id)
    if 'submit' in request.POST:
        name = request.POST['name']
        description = request.POST['description']
        q.name=name
        q.description=description
        q.save()
        return HttpResponse("<script>alert('updated');window.location='/staff_view_category'</script>")
    return render(request,"staff_pages/staff_manage_category.html",{'q':q})


def staff_activecategory(request,id):
    ob = Tbl_category.objects.get(id=id)
    ob.status='active'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/staff_view_category'</script>") 

def staff_inactivecategory(request,id):
    ob = Tbl_category.objects.get(id=id)
    ob.status='inactive'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/staff_view_category'</script>")



def staff_manage_subcat(request):
    cat=Tbl_category.objects.all()
    if 'submit' in request.POST:
        subcat_name = request.POST['subcat_name']
        description = request.POST['description']
        category= request.POST['category']
        m=Tbl_subcat(subcat_name=subcat_name,description=description,status='pending',CATEGORY_id=category)
        m.save()
    return render(request,"staff_pages/staff_manage_subcat.html",{'cat':cat})

def staff_view_subcat(request):
    subcat=Tbl_subcat.objects.all()
    return render(request,"staff_pages/staff_view_subcat.html",{'subcat':subcat})
def update_subcat(request,id):
    subc=Tbl_subcat.objects.get(id=id)
    catview = Tbl_category.objects.all()
    subc=Tbl_subcat.objects.get(id=id)
    catview = Tbl_category.objects.all()
    try:
        if 'submit' in request.POST:
            subcat_name = request.POST['subcat_name']
            description = request.POST['description']
            subc.subcat_name=subcat_name
            subc.description=description
            subc.save()
            return HttpResponse("<script>alert('updated');window.location='/staff_view_subcat'</script>")
    except:
        if 'submit' in request.POST:
            subcat_name = request.POST['subcat_name']
            description = request.POST['description']
            category= request.POST['category']
            subc.subcat_name=subcat_name
            subc.description=description
            subc.CATEGORY_id=category
            subc.save()
        return HttpResponse("<script>alert('updated');window.location='/staff_view_subcat'</script>")
    return render(request,"staff_pages/staff_manage_subcat.html",{'subc':subc,'catview':catview})


def staff_activesubcat(request,id):
    ob = Tbl_subcat.objects.get(id=id)
    ob.status='active'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/staff_view_subcat'</script>")

def staff_inactivesubcat(request,id):
    ob = Tbl_subcat.objects.get(id=id)
    ob.status='inactive'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/staff_view_subcat'</script>")




def staff_manage_product(request):
    catview = Tbl_subcat.objects.all()
    if 'submit' in request.POST:
        item_name = request.POST['item_name']
        description = request.POST['description']
        rate = request.POST['rate']
        qty = request.POST['qty']
        image=request.FILES['image']
        subcatergory = request.POST['sub_cat']
        q=Tbl_item(item_name=item_name,description=description,rate=rate,qty=qty,image=image,SUBCAT_id=subcatergory,status='pending')
        q.save()
        return HttpResponse("<script>alert('Product Added');window.location='/staff_manage_product'</script>")
    return render(request,"staff_pages/staff_manage_product.html",{'catview':catview})

def staff_view_product(request):
    proview = Tbl_item.objects.all()
    return render(request,"staff_pages/staff_view_product.html",{'proview':proview})


def update_product(request,id):
    p=Tbl_item.objects.get(id=id)
    catview = Tbl_subcat.objects.all()
    try:
       if 'submit' in request.POST:
            item_name = request.POST['item_name']
            description = request.POST['description']
            rate = request.POST['rate']
            qty = request.POST['qty']
            image=request.FILES['image']
            subcatergory = request.POST['sub_cat']
            p.item_name=item_name
            p.description=description
            p.rate=rate
            p.qty=qty
            p.image=image
            p.SUBCAT_id=subcatergory
            p.save
            return HttpResponse("<script>alert('Product Updated');window.location='/staff_view_product'</script>")

    except:
       if 'submit' in request.POST:
            item_name = request.POST['item_name']
            description = request.POST['description']
            rate = request.POST['rate']
            qty = request.POST['qty']
            subcatergory = request.POST['sub_cat']
            p.item_name=item_name
            p.description=description
            p.rate=rate
            p.qty=qty
            p.SUBCAT_id=subcatergory
            p.save
            return HttpResponse("<script>alert('Product Updated');window.location='/staff_view_product'</script>")
    return render(request,"staff_pages/staff_manage_product.html",{'p':p,'catview':catview})



def staff_activeproduct(request,id):
    ob = Tbl_item.objects.get(id=id)
    ob.status='active'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/staff_view_product'</script>") 

def staff_inactiveproduct(request,id):
    ob = Tbl_item.objects.get(id=id)
    ob.status='inactive'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/staff_view_product'</script>")


def staff_view_payment_status(request):
    payview=Tbl_payment.objects.all()
    return render(request,'staff_pages/staff_view_payment_status.html',{'payview':payview})




def staff_view_purchase(request):
    q=Tbl_order.objects.all()
    return render(request,'staff_pages/staff_view_purchase.html',{'q':q})
# ------------------------------------------------------------------customer-------------------
# -----------------------------------------------------------------------------------------------

def customer_home(request):
    return render(request,"customer_pages/customer_home.html")

def customer_dashboard(request):
    return render(request,'customer_pages/customer_dashboard.html')



def customer_view_profile(request):

    sv=Tbl_customer.objects.filter(id=request.session['cid'])
    return render(request,"customer_pages/customer_view_profile.html",{'sv':sv})

def customer_view_products(request):
    sv=Tbl_item.objects.all()
    return render(request,"customer_pages/customer_view_products.html",{'sv':sv})
def add_to_cart(request, id):
    q = Tbl_item.objects.get(id=id)
    amount = q.rate
    if Tbl_cartmaster.objects.filter(CUST_id=request.session['cid'], cartmas_status='pending').exists():
        cart_master = Tbl_cartmaster.objects.get(CUST_id=request.session['cid'], cartmas_status='pending')
        if Tbl_cartchild.objects.filter(CARTMAS_id=cart_master.pk, ITEM_id=id).exists():
            # If the item already exists in the cart, increment its quantity
            cart_child = Tbl_cartchild.objects.get(CARTMAS_id=cart_master.pk, ITEM_id=id)
            cart_child.cartcid_qty += 1
            cart_child.save()
        else:
            # If the item is not in the cart, create a new entry
            cart_child = Tbl_cartchild(cartcid_qty=1, CARTMAS_id=cart_master.pk, ITEM_id=id)
            cart_child.save()
    
            cart_master.tot_amt =int(cart_master.tot_amt)+ int(amount)
            cart_master.save()
        
        return HttpResponse("<script>alert('success');window.location='/customer_view_cart';</script>")
    else:
        cart_master = Tbl_cartmaster(tot_amt=amount, cartmas_status='pending', CUST_id=request.session['cid'])
        cart_master.save()
        cart_child = Tbl_cartchild(cartcid_qty=1, CARTMAS_id=cart_master.pk, ITEM_id=id)
        cart_child.save()
        return HttpResponse("<script>alert('success');window.location='/customer_view_cart';</script>")


            
def customer_view_cart(request):
   

    if Tbl_cartchild.objects.filter(CARTMAS__CUST_id=request.session.get('cid'), CARTMAS__cartmas_status='pending').exists():
        q = Tbl_cartchild.objects.filter(CARTMAS__CUST_id=request.session.get('cid'), CARTMAS__cartmas_status='pending')
        m = Tbl_cartmaster.objects.get(CUST_id=request.session.get('cid'), cartmas_status='pending')
        return render(request, 'customer_pages/customer_view_cart.html', {'q': q, 'm': m}) 
    else:
        return HttpResponse("<script>alert('Cart is empty');window.location='/customer_home';</script>")
    
 

def remove_cart(request,id):
    q = Tbl_cartchild.objects.get(id=id)
    amount = q.ITEM.rate
    cid = q.CARTMAS_id
    cart_master = Tbl_cartmaster.objects.get(id=cid)
    tamount = int(q.ITEM.rate) * int(q.cartcid_qty)
    if int(q.cartcid_qty) > 1:
        q.cartcid_qty = str(int(q.cartcid_qty) - 1)
        q.save()
    else:
        q.delete()
    cart_master.tot_amt = max(0, float(cart_master.tot_amt) - float(amount))
    cart_master.save()
    return HttpResponse("<script>alert('removed');window.location='/customer_view_cart'</script>")
    
def increment_qty(request,id):
    
    q2 = Tbl_cartchild.objects.get(id=id)
    q2.cartcid_qty = str(int(q2.cartcid_qty) + 1)
    q2.save()

    q3 = Tbl_cartmaster.objects.get(id=q2.CARTMAS_id)
    q3.tot_amt = str(float(q3.tot_amt) + float(q2.ITEM.rate))
    q3.save()
    qq = int(q2.cartcid_qty)
    q4 = q2.ITEM_id
    q5 = tbl_stock.objects.get(ITEM_id=q4)
    q5.quantity = int(q5.quantity)
    q5.save()
    return HttpResponse("<script>alert('Quantity added successfully.');window.location='/customer_view_cart'</script>")


def decrement_qty(request,id):
    q2 = Tbl_cartchild.objects.get(id=id)
    cart_qty = int(q2.cartcid_qty)
    if cart_qty > 1:
        q2.cartcid_qty = str(cart_qty - 1)
        q2.save()

        qq = int(q2.cartcid_qty)
        q4 = q2.ITEM_id
        q5 = tbl_stock.objects.get(ITEM_id=q4)
        q5.quantity = int(q5.quantity) + 1
        q5.save()
    else:
        return HttpResponse("<script>alert('Quantity must be a minimum of 1.');window.location='/customer_view_cart'</script>")
    return HttpResponse("<script>alert('Quantity removed successfully.');window.location='/customer_view_cart';</script>")


import datetime
def customer_order(request, id):
    q = Tbl_cartmaster.objects.get(id=id)
    amount = q.tot_amt
    q.cartmas_status='ordered'
    q.save()

    if 'submit' in request.POST:
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        phone = request.POST['phone']
        place = request.POST['place']
        pin = request.POST['pin']
        post = request.POST['post']
        street = request.POST['street']
        city = request.POST['city']
        district = request.POST['district']
      
        

        latest_bill_no = Tbl_order.objects.aggregate(max_bill_no=Max('bill_no'))['max_bill_no']


        if latest_bill_no is None:
            latest_bill_no = 1000


        new_bill_no = int(latest_bill_no) + 1
        
      
        q = Tbl_order(
            first_name=first_name, last_name=last_name, phone=phone, pin=pin, post=post,place=place, street=street,
            city=city, district=district,status='pending', order_date=datetime.datetime.now(),
            amount=amount, bill_no=new_bill_no,CARTMAS_id=id
        )
        q.save()
        id2=q.pk
        return HttpResponse(f"<script>alert('ordered');window.location='/customer_payment/{id2}'</script>")
        
    return render(request, 'customer_pages/customer_order.html')

 



def customer_payment(request, id):
    s=Tbl_order.objects.get(id=id)
    f = None  
    if Tbl_card.objects.filter(CUST_id=request.session['cid']).exists():
     
        f = Tbl_card.objects.filter(CUST_id=request.session['cid']).latest('id')

    if 'submit' in request.POST:
        dd=id
        card_no = request.POST.get('card_no')
        card_Holder_name = request.POST.get('card_Holder_name')
        Expiry_date = request.POST.get('Expiry_date')
        cvv=request.POST.get('cvv')


        if not f:
            
            f = Tbl_card(card_no=card_no, Expiry_date=Expiry_date, card_Holder_name=card_Holder_name, CUST_id=request.session['cid'],cvv=cvv)
            f.save()

       
        qi = Tbl_payment(payment_date=datetime.datetime.now(), payment_status='payment successful', CARD_id=f.pk, ORDER_id=id) 
        qi.save()
      
        
        return HttpResponse(f"<script>alert('payment successful');window.location='/customer_bill/{dd}'</script>")
         
    return render(request, 'customer_pages/customer_payment.html', {'f': f,'s':s})


def customer_bill(request, id):
    q = Tbl_order.objects.get(id=id)
    qt = Tbl_payment.objects.filter(ORDER_id=id)  # Use filter instead of get
    qi = Tbl_cartchild.objects.filter(CARTMAS_id=q.CARTMAS_id)
    return render(request,'customer_pages/customer_bill.html', {'q': q, 'qi': qi, 'qt': qt})

def logout(request):
    return render('login.html')






def custbus_dashboard(request):
    return render(request,'customer_pages/custbus_dashboard.html')


def courier_home(request):
    return render(request,'courier_pages/index.html')

def view_assigned_courier(request):
    q=Tbl_courier_assign.objects.filter(COURIER_id=request.session['cdid'])
    return render(request,'courier_pages/view_assigned_courier.html',{'q':q,})

def view_customer_assignoerder(request):
    q1=Tbl_custcourier_assign.objects.filter(COURIER_id=request.session['cdid'])
    return render(request,'courier_pages/view_customer_assignoerder.html',{'q1':q1})


def update_status(request,id):
     if 'submit' in request.POST:
        status=request.POST['status']
        q=Tbl_courier_assign.objects.get(id=id)
        q.assign_Status=status
        q.save()
        orderid=q.ORDER_id
        qi=Tbl_order.objects.get(id=orderid)
        qi.status=status
        qi.save()
        return HttpResponse("<script>alert('statusupdated');window.location='/view_assigned_courier'</script>")
     return render(request,'courier_pages/update_status.html')

def custupdate_status(request,id):
     if 'submit' in request.POST:
        status=request.POST['status']
        q=Tbl_custcourier_assign.objects.get(id=id)
        q.assign_Status=status
        q.save()
        orderadminid=q.ORDERADMIN_id
        qi=Tbl_orderadmin.objects.get(id=orderadminid)
        qi.status=status
        qi.save()
        return HttpResponse("<script>alert('statusupdated');window.location='/view_customer_assignoerder'</script>")
     return render(request,'courier_pages/custupdate_status.html')
    



def customer_add_raw_material(request):
    m=Tbl_category.objects.all()
    if 'submit' in request.POST:
        item_name = request.POST['item_name']
        description = request.POST['description']
        rate = request.POST['rate']
        qty = request.POST['qty']
        category=request.POST['sub_cat']
        image=request.FILES['image']
        q=Tbl_raw_material(item_name=item_name,description=description,rate=rate,qty=qty,image=image,CATEGORY_id=category, CUST_id=request.session['cid'] ,status='pending')
        q.save()
        return HttpResponse("<script>alert('Product Added');window.location='/customer_add_raw_material'</script>")
    return render(request,'customer_pages/customer_add_raw_material.html',{'m':m})



def customer_view_raw_material(request):
    proview = Tbl_raw_material.objects.filter(CUST_id=request.session['cid'])
    return render(request,'customer_pages/customer_view_raw_material.html',{'proview':proview})


def update_raw(request,id):
    p=Tbl_raw_material.objects.get(id=id)
    catview = Tbl_category.objects.all()
    try:
       if 'submit' in request.POST:
            item_name = request.POST['item_name']
            description = request.POST['description']
            rate = request.POST['rate']
            qty = request.POST['qty']
            image=request.FILES['image']
            catergory = request.POST['sub_cat']
            p.item_name=item_name
            p.description=description
            p.rate=rate
            p.qty=qty
            p.image=image
            p.CATEGORY_id=catergory
            p.save
            return HttpResponse("<script>alert('Product Updated');window.location='/customer_view_raw_material'</script>")

    except:
       if 'submit' in request.POST:
            item_name = request.POST['item_name']
            description = request.POST['description']
            rate = request.POST['rate']
            qty = request.POST['qty']
            catergory = request.POST['sub_cat']
            p.item_name=item_name
            p.description=description
            p.rate=rate
            p.qty=qty
            p.CATEGORY_id=catergory
            p.save
            return HttpResponse("<script>alert('Product Updated');window.location='/customer_view_raw_material'</script>")
    return render(request,"customer_pages/customer_add_raw_material.html",{'p':p,'catview':catview})

    # return render(request,'customer_pages/customer_view_raw_material.html')


def cust_activecategory(request,id):
    ob = Tbl_raw_material.objects.get(id=id)
    ob.status='active'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/customer_view_raw_material'</script>") 

def cust_inactivecategory(request,id):
    ob = Tbl_raw_material.objects.get(id=id)
    ob.status='inactive'
    ob.save()
    return HttpResponse("<script>alert('Successfully Updated');window.location='/customer_view_raw_material'</script>")






















def customer_view_oreder(request):
    qq=Tbl_orderadmin.objects.filter(PURMAS__CUST_id=request.session['cid'])
    return render(request,'customer_pages/customer_view_oreder.html',{'qq':qq})


def customer_view_admin_paymnet(request):
    q=Tbl_payment.objects.filter(payment_status='payment successful by admin')
    return render(request,'customer_pages/customer_view_admin_paymnet.html',{'q':q})





def cust_assign_courierservice(request, id):
    q = Tbl_courier.objects.all()
    courier_id=request.session['cid']
    if 'submit' in request.POST:
        courier_id = request.POST['courier']
        # Assuming Tbl_courier_assign is a model, create an instance and save it
        assign_instance = Tbl_custcourier_assign(assign_date=datetime.datetime.now(), assign_Status='pending', ORDERADMIN_id=id, COURIER_id=courier_id)
        assign_instance.save()
        # Update the status of Tbl_order instance
        order_instance = Tbl_orderadmin.objects.get(id=id)
        order_instance.status = 'assigned'
        order_instance.save()
        return HttpResponse("<script>alert('assigned');window.location='/customer_view_oreder'</script>")
    return render(request,"customer_pages/cust_assign_courierservice.html",{'q':q})