/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 5.7.9 : Database - greenhub
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
USE `greenhub`;

/*Table structure for table `auth_group` */

DROP TABLE IF EXISTS `auth_group`;

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `auth_group` */

/*Table structure for table `auth_group_permissions` */

DROP TABLE IF EXISTS `auth_group_permissions`;

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_group_id_b120cbf9` (`group_id`),
  KEY `auth_group_permissions_permission_id_84c5c92e` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `auth_group_permissions` */

/*Table structure for table `auth_permission` */

DROP TABLE IF EXISTS `auth_permission`;

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  KEY `auth_permission_content_type_id_2f476e4b` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=latin1;

/*Data for the table `auth_permission` */

insert  into `auth_permission`(`id`,`name`,`content_type_id`,`codename`) values 
(1,'Can add log entry',1,'add_logentry'),
(2,'Can change log entry',1,'change_logentry'),
(3,'Can delete log entry',1,'delete_logentry'),
(4,'Can view log entry',1,'view_logentry'),
(5,'Can add permission',2,'add_permission'),
(6,'Can change permission',2,'change_permission'),
(7,'Can delete permission',2,'delete_permission'),
(8,'Can view permission',2,'view_permission'),
(9,'Can add group',3,'add_group'),
(10,'Can change group',3,'change_group'),
(11,'Can delete group',3,'delete_group'),
(12,'Can view group',3,'view_group'),
(13,'Can add user',4,'add_user'),
(14,'Can change user',4,'change_user'),
(15,'Can delete user',4,'delete_user'),
(16,'Can view user',4,'view_user'),
(17,'Can add content type',5,'add_contenttype'),
(18,'Can change content type',5,'change_contenttype'),
(19,'Can delete content type',5,'delete_contenttype'),
(20,'Can view content type',5,'view_contenttype'),
(21,'Can add session',6,'add_session'),
(22,'Can change session',6,'change_session'),
(23,'Can delete session',6,'delete_session'),
(24,'Can view session',6,'view_session'),
(25,'Can add tbl_card',7,'add_tbl_card'),
(26,'Can change tbl_card',7,'change_tbl_card'),
(27,'Can delete tbl_card',7,'delete_tbl_card'),
(28,'Can view tbl_card',7,'view_tbl_card'),
(29,'Can add tbl_cartmaster',8,'add_tbl_cartmaster'),
(30,'Can change tbl_cartmaster',8,'change_tbl_cartmaster'),
(31,'Can delete tbl_cartmaster',8,'delete_tbl_cartmaster'),
(32,'Can view tbl_cartmaster',8,'view_tbl_cartmaster'),
(33,'Can add tbl_category',9,'add_tbl_category'),
(34,'Can change tbl_category',9,'change_tbl_category'),
(35,'Can delete tbl_category',9,'delete_tbl_category'),
(36,'Can view tbl_category',9,'view_tbl_category'),
(37,'Can add tbl_courier',10,'add_tbl_courier'),
(38,'Can change tbl_courier',10,'change_tbl_courier'),
(39,'Can delete tbl_courier',10,'delete_tbl_courier'),
(40,'Can view tbl_courier',10,'view_tbl_courier'),
(41,'Can add tbl_courier_assign',11,'add_tbl_courier_assign'),
(42,'Can change tbl_courier_assign',11,'change_tbl_courier_assign'),
(43,'Can delete tbl_courier_assign',11,'delete_tbl_courier_assign'),
(44,'Can view tbl_courier_assign',11,'view_tbl_courier_assign'),
(45,'Can add tbl_customer',12,'add_tbl_customer'),
(46,'Can change tbl_customer',12,'change_tbl_customer'),
(47,'Can delete tbl_customer',12,'delete_tbl_customer'),
(48,'Can view tbl_customer',12,'view_tbl_customer'),
(49,'Can add tbl_login',13,'add_tbl_login'),
(50,'Can change tbl_login',13,'change_tbl_login'),
(51,'Can delete tbl_login',13,'delete_tbl_login'),
(52,'Can view tbl_login',13,'view_tbl_login'),
(53,'Can add tbl_order',14,'add_tbl_order'),
(54,'Can change tbl_order',14,'change_tbl_order'),
(55,'Can delete tbl_order',14,'delete_tbl_order'),
(56,'Can view tbl_order',14,'view_tbl_order'),
(57,'Can add tbl_subcat',15,'add_tbl_subcat'),
(58,'Can change tbl_subcat',15,'change_tbl_subcat'),
(59,'Can delete tbl_subcat',15,'delete_tbl_subcat'),
(60,'Can view tbl_subcat',15,'view_tbl_subcat'),
(61,'Can add tbl_staff',16,'add_tbl_staff'),
(62,'Can change tbl_staff',16,'change_tbl_staff'),
(63,'Can delete tbl_staff',16,'delete_tbl_staff'),
(64,'Can view tbl_staff',16,'view_tbl_staff'),
(65,'Can add tbl_purmas',17,'add_tbl_purmas'),
(66,'Can change tbl_purmas',17,'change_tbl_purmas'),
(67,'Can delete tbl_purmas',17,'delete_tbl_purmas'),
(68,'Can view tbl_purmas',17,'view_tbl_purmas'),
(69,'Can add tbl_purchild',18,'add_tbl_purchild'),
(70,'Can change tbl_purchild',18,'change_tbl_purchild'),
(71,'Can delete tbl_purchild',18,'delete_tbl_purchild'),
(72,'Can view tbl_purchild',18,'view_tbl_purchild'),
(73,'Can add tbl_payment',19,'add_tbl_payment'),
(74,'Can change tbl_payment',19,'change_tbl_payment'),
(75,'Can delete tbl_payment',19,'delete_tbl_payment'),
(76,'Can view tbl_payment',19,'view_tbl_payment'),
(77,'Can add tbl_item',20,'add_tbl_item'),
(78,'Can change tbl_item',20,'change_tbl_item'),
(79,'Can delete tbl_item',20,'delete_tbl_item'),
(80,'Can view tbl_item',20,'view_tbl_item'),
(81,'Can add tbl_delivery',21,'add_tbl_delivery'),
(82,'Can change tbl_delivery',21,'change_tbl_delivery'),
(83,'Can delete tbl_delivery',21,'delete_tbl_delivery'),
(84,'Can view tbl_delivery',21,'view_tbl_delivery'),
(85,'Can add tbl_cartchild',22,'add_tbl_cartchild'),
(86,'Can change tbl_cartchild',22,'change_tbl_cartchild'),
(87,'Can delete tbl_cartchild',22,'delete_tbl_cartchild'),
(88,'Can view tbl_cartchild',22,'view_tbl_cartchild'),
(89,'Can add tbl_raw_material',23,'add_tbl_raw_material'),
(90,'Can change tbl_raw_material',23,'change_tbl_raw_material'),
(91,'Can delete tbl_raw_material',23,'delete_tbl_raw_material'),
(92,'Can view tbl_raw_material',23,'view_tbl_raw_material'),
(93,'Can add tbl_orderadmin',24,'add_tbl_orderadmin'),
(94,'Can change tbl_orderadmin',24,'change_tbl_orderadmin'),
(95,'Can delete tbl_orderadmin',24,'delete_tbl_orderadmin'),
(96,'Can view tbl_orderadmin',24,'view_tbl_orderadmin'),
(97,'Can add tbl_custcourier_assign',25,'add_tbl_custcourier_assign'),
(98,'Can change tbl_custcourier_assign',25,'change_tbl_custcourier_assign'),
(99,'Can delete tbl_custcourier_assign',25,'delete_tbl_custcourier_assign'),
(100,'Can view tbl_custcourier_assign',25,'view_tbl_custcourier_assign'),
(101,'Can add tbl_stock',26,'add_tbl_stock'),
(102,'Can change tbl_stock',26,'change_tbl_stock'),
(103,'Can delete tbl_stock',26,'delete_tbl_stock'),
(104,'Can view tbl_stock',26,'view_tbl_stock');

/*Table structure for table `auth_user` */

DROP TABLE IF EXISTS `auth_user`;

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `auth_user` */

/*Table structure for table `auth_user_groups` */

DROP TABLE IF EXISTS `auth_user_groups`;

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_user_id_6a12ed8b` (`user_id`),
  KEY `auth_user_groups_group_id_97559544` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `auth_user_groups` */

/*Table structure for table `auth_user_user_permissions` */

DROP TABLE IF EXISTS `auth_user_user_permissions`;

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_user_id_a95ead1b` (`user_id`),
  KEY `auth_user_user_permissions_permission_id_1fbb5f2c` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `auth_user_user_permissions` */

/*Table structure for table `django_admin_log` */

DROP TABLE IF EXISTS `django_admin_log`;

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `django_admin_log` */

/*Table structure for table `django_content_type` */

DROP TABLE IF EXISTS `django_content_type`;

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

/*Data for the table `django_content_type` */

insert  into `django_content_type`(`id`,`app_label`,`model`) values 
(1,'admin','logentry'),
(2,'auth','permission'),
(3,'auth','group'),
(4,'auth','user'),
(5,'contenttypes','contenttype'),
(6,'sessions','session'),
(7,'green_apk','tbl_card'),
(8,'green_apk','tbl_cartmaster'),
(9,'green_apk','tbl_category'),
(10,'green_apk','tbl_courier'),
(11,'green_apk','tbl_courier_assign'),
(12,'green_apk','tbl_customer'),
(13,'green_apk','tbl_login'),
(14,'green_apk','tbl_order'),
(15,'green_apk','tbl_subcat'),
(16,'green_apk','tbl_staff'),
(17,'green_apk','tbl_purmas'),
(18,'green_apk','tbl_purchild'),
(19,'green_apk','tbl_payment'),
(20,'green_apk','tbl_item'),
(21,'green_apk','tbl_delivery'),
(22,'green_apk','tbl_cartchild'),
(23,'green_apk','tbl_raw_material'),
(24,'green_apk','tbl_orderadmin'),
(25,'green_apk','tbl_custcourier_assign'),
(26,'green_apk','tbl_stock');

/*Table structure for table `django_migrations` */

DROP TABLE IF EXISTS `django_migrations`;

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

/*Data for the table `django_migrations` */

insert  into `django_migrations`(`id`,`app`,`name`,`applied`) values 
(1,'contenttypes','0001_initial','2024-02-15 04:48:17.469702'),
(2,'auth','0001_initial','2024-02-15 04:48:17.684092'),
(3,'admin','0001_initial','2024-02-15 04:48:17.737232'),
(4,'admin','0002_logentry_remove_auto_add','2024-02-15 04:48:17.743758'),
(5,'admin','0003_logentry_add_action_flag_choices','2024-02-15 04:48:17.750819'),
(6,'contenttypes','0002_remove_content_type_name','2024-02-15 04:48:17.778387'),
(7,'auth','0002_alter_permission_name_max_length','2024-02-15 04:48:17.792116'),
(8,'auth','0003_alter_user_email_max_length','2024-02-15 04:48:17.806174'),
(9,'auth','0004_alter_user_username_opts','2024-02-15 04:48:17.814863'),
(10,'auth','0005_alter_user_last_login_null','2024-02-15 04:48:17.830879'),
(11,'auth','0006_require_contenttypes_0002','2024-02-15 04:48:17.835394'),
(12,'auth','0007_alter_validators_add_error_messages','2024-02-15 04:48:17.843915'),
(13,'auth','0008_alter_user_username_max_length','2024-02-15 04:48:17.859934'),
(14,'auth','0009_alter_user_last_name_max_length','2024-02-15 04:48:17.882281'),
(15,'auth','0010_alter_group_name_max_length','2024-02-15 04:48:17.906938'),
(16,'auth','0011_update_proxy_permissions','2024-02-15 04:48:17.921573'),
(17,'auth','0012_alter_user_first_name_max_length','2024-02-15 04:48:17.952407'),
(18,'green_apk','0001_initial','2024-02-15 04:48:18.418161'),
(19,'green_apk','0002_auto_20240127_1709','2024-02-15 04:48:18.476086'),
(20,'green_apk','0003_auto_20240130_1238','2024-02-15 04:48:18.653564'),
(21,'green_apk','0004_remove_tbl_login_status','2024-02-15 04:48:18.669321'),
(22,'sessions','0001_initial','2024-02-15 04:48:18.700806'),
(23,'green_apk','0005_tbl_item_image','2024-02-15 14:40:23.936758'),
(24,'green_apk','0006_auto_20240216_1031','2024-02-16 05:01:40.805766'),
(25,'green_apk','0007_auto_20240216_1734','2024-02-16 12:04:47.431702'),
(26,'green_apk','0008_alter_tbl_cartchild_item','2024-02-16 14:17:38.491892'),
(27,'green_apk','0009_alter_tbl_item_rate','2024-02-17 14:19:08.011999'),
(28,'green_apk','0010_alter_tbl_cartchild_cartcid_qty','2024-02-17 14:27:30.069725'),
(29,'green_apk','0011_tbl_order_bill_no','2024-02-18 11:10:01.888322'),
(30,'green_apk','0012_auto_20240218_1651','2024-02-18 11:21:25.528770'),
(31,'green_apk','0013_tbl_payment_payment_status','2024-02-18 11:38:12.519166'),
(32,'green_apk','0014_tbl_customer_type','2024-02-18 12:48:49.157882'),
(33,'green_apk','0015_auto_20240219_0101','2024-02-18 19:31:10.875392'),
(34,'green_apk','0016_auto_20240219_1714','2024-02-19 11:44:37.931387'),
(35,'green_apk','0017_auto_20240219_1910','2024-02-19 13:40:53.079034'),
(36,'green_apk','0018_auto_20240219_2041','2024-02-19 15:11:55.131337'),
(37,'green_apk','0019_rename_customer_tbl_purmas_cust','2024-02-19 15:12:46.965926'),
(38,'green_apk','0020_alter_tbl_order_post','2024-02-19 20:07:48.906880'),
(39,'green_apk','0021_alter_tbl_order_post','2024-02-19 20:08:55.918673'),
(40,'green_apk','0022_tbl_order_purmas','2024-02-20 04:18:16.363618'),
(41,'green_apk','0023_auto_20240220_0956','2024-02-20 04:26:41.129882'),
(42,'green_apk','0024_remove_tbl_customer_type','2024-02-21 17:09:30.392583'),
(43,'green_apk','0025_tbl_custcourier_assign','2024-02-21 17:36:53.012643'),
(44,'green_apk','0026_tbl_stock','2024-03-02 06:11:28.405124');

/*Table structure for table `django_session` */

DROP TABLE IF EXISTS `django_session`;

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `django_session` */

insert  into `django_session`(`session_key`,`session_data`,`expire_date`) values 
('rndrlaav4vzoo2nc4yxeqvsuysiu5tj4','.eJyrVsrJTFGyMtRRKobSyTA6BcQwrgUApqsJeA:1rd3MK:CwOSCFDvYQBaRgXRxD0DDTliZcQV9YhQHkkidN29CAM','2024-03-07 07:19:08.190676'),
('2qlfbrq0j7741dxnut0pvh58vsfq1ot7','.eJyrVsrJTFGyMtRRSobRKSCGkY5SMVigFgCmtgl3:1rdQbM:CgJZHruGkxFuck_c6ryeEcSkk_-cSXROm57EwGoYtCg','2024-03-08 08:08:12.404388'),
('ax0juw6dtfak4pw72dwnj49pzj63thvr','eyJsaWQiOjcsInNpZCI6MSwiY2lkIjoxfQ:1reTvs:4dPyiKqkBJtmCxRL4_Os4Qur44pmZ86FQZ3OcVGK_0o','2024-03-11 05:53:44.361038'),
('0w6adyi0524cjd6zx3h0rrgalqxdbpu6','eyJsaWQiOjQsImNpZCI6MSwiY2RpZCI6MX0:1rfI8U:Qg6kKcL7iUJXBuVBcmJWmK2jDvgQIyDmf9m8h-R_ctQ','2024-03-13 11:30:06.394590'),
('lv29y7jy77zw4zsgxsvcf8a0pdrpz681','eyJsaWQiOjEsImNpZCI6MX0:1rgKCU:TD-En0yfC71YupUWrt-qINKKyChOSYICIfle_-SDEJc','2024-03-16 07:54:30.880857');

/*Table structure for table `green_apk_tbl_card` */

DROP TABLE IF EXISTS `green_apk_tbl_card`;

CREATE TABLE `green_apk_tbl_card` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `card_no` varchar(100) NOT NULL,
  `Expiry_date` varchar(100) NOT NULL,
  `card_Holder_name` varchar(100) NOT NULL,
  `CUST_id` bigint(20) NOT NULL,
  `cvv` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_card_CUST_id_id_420edc57` (`CUST_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_card` */

insert  into `green_apk_tbl_card`(`id`,`card_no`,`Expiry_date`,`card_Holder_name`,`CUST_id`,`cvv`) values 
(1,'123456789','2024-02-13','asdxyz',1,'123'),
(2,'123456789','2024-02-14','qwertyui',15000,'123'),
(3,'123456789','2024-02-14','qwertyuio',15000,'123'),
(4,'1234567890','2024-02-14','qwertyuio',15000,'1234'),
(5,'1234567890','2024-02-20','qwertyuio',15000,'123'),
(6,'123456789','2024-02-22','qwertyuiop',15000,'123'),
(7,'1234567890','2024-02-22','asdfghjkl',15000,'123'),
(8,'123456789','2024-03-01','asdfghj',15000,'123');

/*Table structure for table `green_apk_tbl_cartchild` */

DROP TABLE IF EXISTS `green_apk_tbl_cartchild`;

CREATE TABLE `green_apk_tbl_cartchild` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cartcid_qty` int(11) NOT NULL,
  `CARTMAS_id` bigint(20) NOT NULL,
  `ITEM_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_cartchild_CARTMAS_id_id_19818310` (`CARTMAS_id`),
  KEY `green_apk_tbl_cartchild_ITEM_id_id_4b816372` (`ITEM_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_cartchild` */

insert  into `green_apk_tbl_cartchild`(`id`,`cartcid_qty`,`CARTMAS_id`,`ITEM_id`) values 
(3,2,1,1);

/*Table structure for table `green_apk_tbl_cartmaster` */

DROP TABLE IF EXISTS `green_apk_tbl_cartmaster`;

CREATE TABLE `green_apk_tbl_cartmaster` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tot_amt` varchar(100) NOT NULL,
  `cartmas_status` varchar(100) NOT NULL,
  `CUST_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_cartmaster_CUST_id_id_bbeeff1c` (`CUST_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_cartmaster` */

insert  into `green_apk_tbl_cartmaster`(`id`,`tot_amt`,`cartmas_status`,`CUST_id`) values 
(1,'100.0','ordered',1);

/*Table structure for table `green_apk_tbl_category` */

DROP TABLE IF EXISTS `green_apk_tbl_category`;

CREATE TABLE `green_apk_tbl_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `status` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_category` */

insert  into `green_apk_tbl_category`(`id`,`name`,`description`,`status`) values 
(1,'Paper','papers','pending');

/*Table structure for table `green_apk_tbl_courier` */

DROP TABLE IF EXISTS `green_apk_tbl_courier`;

CREATE TABLE `green_apk_tbl_courier` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `address` varchar(250) NOT NULL,
  `pin` varchar(7) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `status` varchar(15) NOT NULL,
  `LOGIN_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_courier_LOGIN_id_id_ad9a7c1c` (`LOGIN_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_courier` */

insert  into `green_apk_tbl_courier`(`id`,`name`,`address`,`pin`,`phone`,`status`,`LOGIN_id`) values 
(1,'dtdc','abc place, xyz street','676122','7306033950','pending',3);

/*Table structure for table `green_apk_tbl_courier_assign` */

DROP TABLE IF EXISTS `green_apk_tbl_courier_assign`;

CREATE TABLE `green_apk_tbl_courier_assign` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `assign_date` varchar(100) NOT NULL,
  `assign_Status` varchar(100) NOT NULL,
  `COURIER_id` bigint(20) NOT NULL,
  `ORDER_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_courier_assign_COURIER_id_id_0d427acc` (`COURIER_id`),
  KEY `green_apk_tbl_courier_assign_ORDER_id_92a1c821` (`ORDER_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_courier_assign` */

insert  into `green_apk_tbl_courier_assign`(`id`,`assign_date`,`assign_Status`,`COURIER_id`,`ORDER_id`) values 
(1,'2024-02-26 20:20:24.874921','delivered',1,1);

/*Table structure for table `green_apk_tbl_custcourier_assign` */

DROP TABLE IF EXISTS `green_apk_tbl_custcourier_assign`;

CREATE TABLE `green_apk_tbl_custcourier_assign` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `assign_date` varchar(100) NOT NULL,
  `assign_Status` varchar(100) NOT NULL,
  `COURIER_id` bigint(20) NOT NULL,
  `ORDERADMIN_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_custcourier_assign_COURIER_id_eba5c09b` (`COURIER_id`),
  KEY `green_apk_tbl_custcourier_assign_ORDERADMIN_id_74ad82f5` (`ORDERADMIN_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_custcourier_assign` */

/*Table structure for table `green_apk_tbl_customer` */

DROP TABLE IF EXISTS `green_apk_tbl_customer`;

CREATE TABLE `green_apk_tbl_customer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `place` varchar(250) NOT NULL,
  `pin` varchar(100) NOT NULL,
  `post` varchar(7) NOT NULL,
  `street` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `district` varchar(100) NOT NULL,
  `status` varchar(15) NOT NULL,
  `LOGIN_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_customer_LOGIN_id_id_96255a76` (`LOGIN_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_customer` */

insert  into `green_apk_tbl_customer`(`id`,`first_name`,`last_name`,`dob`,`gender`,`phone`,`place`,`pin`,`post`,`street`,`city`,`district`,`status`,`LOGIN_id`) values 
(1,'Edwin','tom','2024-02-21','Male','7306033950','kochi','676122','kochin','abc place, xyz street','Manjeri','ernklm','pending',4);

/*Table structure for table `green_apk_tbl_delivery` */

DROP TABLE IF EXISTS `green_apk_tbl_delivery`;

CREATE TABLE `green_apk_tbl_delivery` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `delivery_date` varchar(100) NOT NULL,
  `CARTMAS` varchar(100) NOT NULL,
  `COURIER_ASSIGN_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_delivery_COURIER_ASSIGN_id_id_e0fb5a89` (`COURIER_ASSIGN_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_delivery` */

/*Table structure for table `green_apk_tbl_item` */

DROP TABLE IF EXISTS `green_apk_tbl_item`;

CREATE TABLE `green_apk_tbl_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `rate` double NOT NULL,
  `qty` varchar(100) NOT NULL,
  `status` varchar(15) NOT NULL,
  `image` varchar(100) NOT NULL,
  `SUBCAT_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_item_SUBCAT_id_a1b73bc2` (`SUBCAT_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_item` */

insert  into `green_apk_tbl_item`(`id`,`item_name`,`description`,`rate`,`qty`,`status`,`image`,`SUBCAT_id`) values 
(1,'paper bag','paper',50,'2','active','static/products/bag1.webp',1),
(2,'brown','paper',60,'2','pending','static/products/bag2.jpg',1),
(3,'brown','paper',80,'3','pending','static/products/bag3.jpg',1);

/*Table structure for table `green_apk_tbl_login` */

DROP TABLE IF EXISTS `green_apk_tbl_login`;

CREATE TABLE `green_apk_tbl_login` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `usertype` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_login` */

insert  into `green_apk_tbl_login`(`id`,`username`,`password`,`usertype`) values 
(1,'admin','123','admin'),
(2,'staff1@gmail.com','123','staff'),
(3,'courier@gmail.com','123','courier'),
(4,'customer@gmail.com','123','customer');

/*Table structure for table `green_apk_tbl_order` */

DROP TABLE IF EXISTS `green_apk_tbl_order`;

CREATE TABLE `green_apk_tbl_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_date` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `place` varchar(250) NOT NULL,
  `pin` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `street` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `district` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `CARTMAS_id` bigint(20) NOT NULL,
  `bill_no` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_order_CARTMAS_id_id_213ea528` (`CARTMAS_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_order` */

insert  into `green_apk_tbl_order`(`id`,`order_date`,`amount`,`first_name`,`last_name`,`phone`,`place`,`pin`,`post`,`street`,`city`,`district`,`status`,`CARTMAS_id`,`bill_no`) values 
(1,'2024-02-26 20:03:49.249970','60.0','Edwin','tom','07306033950','kochiii','676122','abc place, xyz street','htdtyyr','Manjeri','KANNUR','delivered',1,'1001'),
(2,'2024-02-28 17:00:55.427495','120.0','Renji','krishnan k','917306033950','kochi','767662','abc place, xyz street','htdtyyr','Manjeri','ihiuhi','pending',2,'1002'),
(3,'2024-03-02 12:51:57.810523','100.0','zzzzz','krishnan k','917306033950','kochi','767662','abc place, xyz street','htdtyyr','Manjeri','KANNUR','pending',1,'1003');

/*Table structure for table `green_apk_tbl_orderadmin` */

DROP TABLE IF EXISTS `green_apk_tbl_orderadmin`;

CREATE TABLE `green_apk_tbl_orderadmin` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_date` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `place` varchar(250) NOT NULL,
  `pin` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `street` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `district` varchar(100) NOT NULL,
  `bill_no` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `PURMAS_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_orderadmin_PURMAS_id_94ac2c8f` (`PURMAS_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_orderadmin` */

insert  into `green_apk_tbl_orderadmin`(`id`,`order_date`,`amount`,`first_name`,`last_name`,`phone`,`place`,`pin`,`post`,`street`,`city`,`district`,`bill_no`,`status`,`PURMAS_id`) values 
(1,'2024-02-26 20:38:25.009075','50.0','Renji','krishnan k','917306033950','kochi','767662','abc place, xyz street','htdtyyr','Manjeri','KANNUR','1001','pending',1),
(2,'2024-02-27 08:54:46.816845','30.0','Renji','krishnan k','917306033950','kochi','767662','abc place, xyz street','htdtyyr','Manjeri','ernklm','1002','pending',2),
(3,'2024-02-27 17:48:49.760177','50.0','Renji','krishnan k','917306033950','kochi','767662','abc place, xyz street','htdtyyr','Manjeri','KANNUR','1003','pending',3);

/*Table structure for table `green_apk_tbl_payment` */

DROP TABLE IF EXISTS `green_apk_tbl_payment`;

CREATE TABLE `green_apk_tbl_payment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payment_date` varchar(100) NOT NULL,
  `CARD_id` bigint(20) NOT NULL,
  `ORDER_id` bigint(20) NOT NULL,
  `payment_status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_payment_CARD_id_id_4b2a11c7` (`CARD_id`),
  KEY `green_apk_tbl_payment_ORDER_id_id_da732e4f` (`ORDER_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_payment` */

insert  into `green_apk_tbl_payment`(`id`,`payment_date`,`CARD_id`,`ORDER_id`,`payment_status`) values 
(1,'2024-02-26 20:19:31.594469',1,1,'payment successful'),
(2,'2024-02-26 20:39:12.246063',2,1,'payment successful by admin'),
(3,'2024-02-26 20:40:27.089995',3,1,'payment successful by admin'),
(4,'2024-02-26 20:41:31.469235',4,1,'payment successful by admin'),
(5,'2024-02-26 20:42:54.449089',5,1,'payment successful by admin'),
(6,'2024-02-26 21:17:21.639780',6,1,'payment successful by admin'),
(7,'2024-02-27 08:55:20.694934',7,2,'payment successful by admin'),
(8,'2024-02-27 17:49:08.031016',8,3,'payment successful by admin'),
(9,'2024-02-28 17:03:46.768585',1,2,'payment successful');

/*Table structure for table `green_apk_tbl_purchild` */

DROP TABLE IF EXISTS `green_apk_tbl_purchild`;

CREATE TABLE `green_apk_tbl_purchild` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purcid_qty` varchar(100) NOT NULL,
  `PURMAS_id` bigint(20) NOT NULL,
  `RAW_MATERIAL_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_purchild_PURMAS_id_id_a7fe7f81` (`PURMAS_id`),
  KEY `green_apk_tbl_purchild_RAW_MATERIAL_id_90683dca` (`RAW_MATERIAL_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_purchild` */

insert  into `green_apk_tbl_purchild`(`id`,`purcid_qty`,`PURMAS_id`,`RAW_MATERIAL_id`) values 
(1,'1',1,2),
(2,'1',2,3),
(3,'2',3,2),
(4,'1',4,2),
(5,'1',5,2),
(6,'1',6,1);

/*Table structure for table `green_apk_tbl_purmas` */

DROP TABLE IF EXISTS `green_apk_tbl_purmas`;

CREATE TABLE `green_apk_tbl_purmas` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `total_amt` varchar(100) NOT NULL,
  `p_status` varchar(15) NOT NULL,
  `CUST_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_purmas_CUSTOMER_id_id_2af45481` (`CUST_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_purmas` */

insert  into `green_apk_tbl_purmas`(`id`,`total_amt`,`p_status`,`CUST_id`) values 
(1,'50.0','ordered',1),
(2,'30.0','ordered',1),
(3,'50.0','ordered',1),
(4,'50.0','ordered',1),
(5,'50.0','ordered',1),
(6,'1.0','pending',1);

/*Table structure for table `green_apk_tbl_raw_material` */

DROP TABLE IF EXISTS `green_apk_tbl_raw_material`;

CREATE TABLE `green_apk_tbl_raw_material` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `rate` double NOT NULL,
  `qty` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `status` varchar(15) NOT NULL,
  `CUST_id` bigint(20) NOT NULL,
  `CATEGORY_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_raw_material_CUST_id_6d9d2a87` (`CUST_id`),
  KEY `green_apk_tbl_raw_material_CATEGORY_id_ecde6fcc` (`CATEGORY_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_raw_material` */

insert  into `green_apk_tbl_raw_material`(`id`,`item_name`,`description`,`rate`,`qty`,`image`,`status`,`CUST_id`,`CATEGORY_id`) values 
(1,'bbb','paper',1,'1','static/products/R.jpg','active',1,1),
(2,'orange','paper',50,'2','static/products/orange.jpg','active',1,1),
(3,'yellow','paper',30,'1','static/products/yellow.jpg','pending',1,1);

/*Table structure for table `green_apk_tbl_staff` */

DROP TABLE IF EXISTS `green_apk_tbl_staff`;

CREATE TABLE `green_apk_tbl_staff` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `place` varchar(250) NOT NULL,
  `pin` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `street` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `LOGIN_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_staff_LOGIN_id_id_e5648775` (`LOGIN_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_staff` */

insert  into `green_apk_tbl_staff`(`id`,`first_name`,`last_name`,`dob`,`gender`,`phone`,`place`,`pin`,`post`,`street`,`city`,`district`,`status`,`LOGIN_id`) values 
(1,'james','rodirigus','2024-02-28','Female','3432434234','kochi','676125','kochin','abc place, xyz street','Manjeri','KANNUR','pending',2);

/*Table structure for table `green_apk_tbl_stock` */

DROP TABLE IF EXISTS `green_apk_tbl_stock`;

CREATE TABLE `green_apk_tbl_stock` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `quantity` int(11) NOT NULL,
  `ITEM_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_stock_ITEM_id_ded125a5` (`ITEM_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_stock` */

insert  into `green_apk_tbl_stock`(`id`,`quantity`,`ITEM_id`) values 
(1,19,1),
(2,20,2),
(3,20,3);

/*Table structure for table `green_apk_tbl_subcat` */

DROP TABLE IF EXISTS `green_apk_tbl_subcat`;

CREATE TABLE `green_apk_tbl_subcat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `subcat_name` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `status` varchar(15) NOT NULL,
  `CATEGORY_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `green_apk_tbl_subcat_CATEGORY_id_id_401b3c6a` (`CATEGORY_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `green_apk_tbl_subcat` */

insert  into `green_apk_tbl_subcat`(`id`,`subcat_name`,`description`,`status`,`CATEGORY_id`) values 
(1,'paper materials','paper','pending',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
