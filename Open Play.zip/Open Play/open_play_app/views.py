from django.shortcuts import render,HttpResponse
from open_play_app.models import *
from django.conf import settings
from django.core.files.storage import FileSystemStorage

from django.http import JsonResponse



from datetime import *




def home(request):
    return render(request,'home.html')


def logins(request):
    if request.method=='POST':
        uname=request.POST['uname']
        psw=request.POST['psw']
        
        try:
            lg=Login.objects.get(username=uname,password=psw)
            print(lg,"///////////////")
            
            request.session['login_id']=lg.pk
            lid=request.session['login_id']
            
            if lg.usertype=='admin':
                return HttpResponse("<script>alert('login successfull');window.location='adminhome';</script>")
            elif lg.usertype=='prop':
                q=Prop.objects.get(login_id=lid)
                if q:
                    
                    request.session['pid']=q.pk
                    
                    return HttpResponse("<script>alert('login successfull');window.location='prophome';</script>")
            
            elif lg.usertype=='user':
                w=User.objects.get(login_id=lid)
                if w:
                     request.session['uid']=w.pk
                    
                return HttpResponse("<script>alert('login successfull');window.location='userhome';</script>")
        except:
            return HttpResponse("<script>alert('login Failed...!!!!');window.location='login';</script>")
    

    return render(request,'login.html')


def adminhome(request):
    return render(request,'adminhome.html')


def view_reviews(request,id):
    q=RatingFeedback.objects.filter(court_id=id)
    return render(request,'view_reviews.html',{'q':q})


def court_review(request,id):
    q=RatingFeedback.objects.filter(court_id=id)
    return render(request,'court_review.html',{'q':q})



def admin_view_user(request):
    q=User.objects.all()
    return render(request,'admin_view_user.html',{'q':q})

def prop_court(request,id):
    q=Court.objects.filter(prop_id=id)
    return render(request,'prop_court.html',{'q':q})


def review_court(request):
    q=Court.objects.all()
    return render(request,'review_court.html',{'q':q})



def block(request,id):
    q=Court.objects.get(pk=id)
    
    q.status='blocked'
    q.save()
    return HttpResponse("<script>alert('Blocked');window.location='/manage_prop'</script>")


def unblock(request,id):
    q=Court.objects.get(pk=id)
    
    q.status='pending'
    q.save()
    return HttpResponse("<script>alert('Unblocked');window.location='/manage_prop'</script>")
    
    


def prophome(request):
    return render(request,'prophome.html')



def userhome(request):
    return render(request,'userhome.html')




def profile(request):
    q=User.objects.filter(user_id=request.session['uid'])
    return render(request,'user_profile.html',{'q':q})






    
def manage_prop(request):
    
    q=Prop.objects.all()
    if request.method=='POST':
        fname=request.POST['fname']
        place=request.POST['place']
        email=request.POST['email']
        phone=request.POST['phone']
        uname=request.POST['uname']
        psw=request.POST['psw']
        
        
        l=Login.objects.filter(username=uname)
        
        if l:
            return HttpResponse("<script>alert('Username Already Exist');window.location='/manage_prop'</script>")
        else:
        
        
            l=Login(username=uname,password=psw,usertype='prop')
            l.save()
            
            t=Prop(prop_name=fname,place=place,email=email,phone=phone,login=l)
            t.save()
            return HttpResponse("<script>alert('Added successfully');window.location='/manage_prop';</script>")
    return render(request,'manage_prop.html',{'q':q})




def manage_court(request):
    
    q=Court.objects.all()
    if request.method=='POST':
        name=request.POST['name']
        location=request.POST['location']
  
        
       
  
            
        t=Court(name=name,place=location,prop_id=request.session['pid'],status='pending')
        t.save()
        return HttpResponse("<script>alert('Added successfully');window.location='/manage_court';</script>")
    return render(request,'manage_court.html',{'q':q})




def add_facilities(request,id):
    
    q=Facilities.objects.filter(court_id=id)
    if request.method=='POST':
        
        des=request.POST['des']
        photo=request.FILES['photo']
        fs=FileSystemStorage()
        image=fs.save(photo.name,photo)
  
        
       
  
            
        t=Facilities(image=image,description=des,court_id=id,date=datetime.now().date())
        t.save()
        return HttpResponse("<script>alert('Added successfully');window.location='/manage_court';</script>")
    return render(request,'add_facilities.html',{'q':q})





def update_profile(request,id):
    
    u=User.objects.get(login_id=id)
    if request.method=='POST':
        
        fname=request.POST['fname']
        place=request.POST['place']
        email=request.POST['email']
        phone=request.POST['phone']
        
        u.full_name=fname
        u.place=place
        u.email=email
        u.phone=phone
        u.save()
       
        return HttpResponse("<script>alert('Updated Successfully');window.location='/profile';</script>")
    return render(request,'user_profile.html',{'u':u})




def user_view_facilities(request,id):
    
    q=Facilities.objects.filter(court_id=id)

    return render(request,'user_view_facilities.html',{'q':q})





def send_feedback(request,id):
    
  
    if request.method=='POST':
        
        re=request.POST['review']
       
  
        
       
  
            
        t=RatingFeedback(review=re,date=datetime.now().date(),court_id=id,user_id=request.session['uid'])
        t.save()
        return HttpResponse("<script>alert('Added successfully');window.location='/user_view_court';</script>")
    return render(request,'send_feedback.html')







def manage_tournament(request):
    e=Court.objects.filter(prop_id=request.session['pid'],status='pending')
    
    q=Tournament.objects.all()
    if request.method=='POST':
        name=request.POST['tname']
        des=request.POST['des']
        cou=request.POST['court']
        
       
        
  
        
       
  
            
        t=Tournament(tournament_name=name,description=des,status='pending',court_id=cou)
        t.save()
        return HttpResponse("<script>alert('Added successfully');window.location='/manage_tournament';</script>")
    return render(request,'manage_tournament.html',{'q':q,'e':e})










   
def register(request):
    
  
    if request.method=='POST':
        fname=request.POST['fname']
        place=request.POST['place']
        email=request.POST['email']
        phone=request.POST['phone']
        uname=request.POST['uname']
        psw=request.POST['psw']
        
        
        l=Login.objects.filter(username=uname)
        
        if l:
            return HttpResponse("<script>alert('Username Already Exist');window.location='/user_reg'</script>")
        else:
        
        
            l=Login(username=uname,password=psw,usertype='user')
            l.save()
            
            t=User(full_name=fname,place=place,email=email,phone=phone,login=l)
            t.save()
            return HttpResponse("<script>alert('Added successfully');window.location='/login';</script>")
    return render(request,'register.html')






def user_view_court(request):
    q=Court.objects.all()
    
    return render(request,'user_view_court.html',{'q':q})




def view_membership_request(request,id):
    q=MembershipRequest.objects.filter(court_id=id)
    
    return render(request,'view_membership_request.html',{'q':q})


def user_view_tour_re(request):
    q=TournamentRequest.objects.filter(user_id=request.session['uid'])
    
    return render(request,'user_view_tour_re.html',{'q':q})


def user_view_schedule(request,id):
    q=Scheduling.objects.filter(tournament_id=id)
    
    return render(request,'user_view_schedule.html',{'q':q})



def tour_request(request,id):
    q=TournamentRequest.objects.filter(tournament_id=id)
    
    return render(request,'tour_request.html',{'q':q})


def user_view_tournament(request,id):
    q=Tournament.objects.filter(court_id=id)
    
    return render(request,'user_view_tournament.html',{'q':q})


def view_schedule(request,id):
    q=Scheduling.objects.filter(tournament_id=id)
    
    return render(request,'view_schedule.html',{'q':q})


def view_winner(request,id):
    q=Winner.objects.filter(tournament_id=id)
    
    return render(request,'view_winner.html',{'q':q})


def user_view_winner(request,id):
    q=Winner.objects.filter(tournament_id=id)
    
    return render(request,'user_view_winner.html',{'q':q})



def user_view_booking(request):
    q=CourtBooking.objects.filter(user_id=request.session['uid'])
    
    return render(request,'user_view_booking.html',{'q':q})


def bookings(request,id):
    q=CourtBooking.objects.filter(court_id=id)
    
    return render(request,'bookings.html',{'q':q})

def other_booking(request):
    q=CourtBooking.objects.exclude(user_id=request.session['uid'])
    
    return render(request,'other_booking.html',{'q':q})


def send_request(request,id):
    a=CourtBookingStatus.objects.filter(user_id=request.session['uid'],court_booking_id=id)
    if a:
        return HttpResponse("<script>alert('Already Requested');window.location='/userhome';</script>")
    else:
        
        
        q=CourtBookingStatus(user_id=request.session['uid'],court_booking_id=id,status='pending')
        q.save()
    
    return HttpResponse("<script>alert('Requested');window.location='/userhome';</script>")


def recent_request(request,id):
    q=CourtBookingStatus.objects.filter(user_id=request.session['uid'],court_booking_id=id)
    
    
    return render(request,'recent_request.html',{'q':q})
    
    
   


def user_request(request,id):
    q=CourtBookingStatus.objects.filter(court_booking_id=id)
    
    
    return render(request,'user_request.html',{'q':q})

def user_book_court(request,id):
    if request.method=="POST":
        gname=request.POST['gname']
        fdate=request.POST['fdate']
        time=request.POST['time']
        
        a=CourtBooking(game_name=gname,for_date=fdate,time=time,court_id=id,user_id=request.session['uid'],date=datetime.now().date(),status='pending')
        a.save()
        return HttpResponse("<script>alert('Requested');window.location='/user_view_court';</script>")
        
        
        
        
    
    return render(request,'user_book_court.html')



def schedule_tour(request,id):
    c=Tournament.objects.get(pk=id)
   
    if request.method=='POST':
        date=request.POST['date']
        
        time=request.POST['time']
        
        d=Scheduling(tournament_date=date,time=time,tournament_id=id)
        d.save()
        
        c.status='scheduled'
        c.save()
        return HttpResponse("<script>alert('Scheduled');window.location='/manage_tournament';</script>")
    
    return render(request,'schedule_tour.html')


def winner_list(request,id):
    a=Winner.objects.filter(tournament_id=id)
    b=TournamentRequest.objects.filter(tournament_id=id)
    if request.method=='POST':
        pos=request.POST['pos']
        user=request.POST['user']
        
        d=Winner(position=pos,date=datetime.now().date(),tournament_id=id,user_id=user)
        d.save()
        return HttpResponse("<script>alert('Added');window.location='/manage_tournament';</script>")
    
    return render(request,'winner_list.html',{'q':a,'b':b})


def accept_mr(request,id):
    q=MembershipRequest.objects.get(pk=id)
    q.status='accepted'
    q.save()
    return HttpResponse("<script>alert('Accepted');window.location='/manage_court';</script>")

def reject_mr(request,id):
    q=MembershipRequest.objects.get(pk=id)
    q.status='rejected'
    q.save()
    return HttpResponse("<script>alert('Rejected');window.location='/manage_court';</script>")


def accept_user(request,id):
    q=CourtBookingStatus.objects.get(court_booking_id=id)
    q.status='accepted'
    q.save()
    return HttpResponse("<script>alert('Accepted');window.location='/userhome';</script>")


def reject_user(request,id):
    q=CourtBookingStatus.objects.get(court_booking_id=id)
    q.status='rejected'
    q.save()
    return HttpResponse("<script>alert('Accepted');window.location='/userhome';</script>")



def accept_tour_req(request,id):
    q=TournamentRequest.objects.get(pk=id)
    q.status='accepted'
    q.save()
    return HttpResponse("<script>alert('Accepted');window.location='/manage_tournament';</script>")


def accept_book(request,id):
    q=CourtBooking.objects.get(pk=id)
    q.status='accepted'
    q.save()
    return HttpResponse("<script>alert('Accepted');window.location='/manage_court';</script>")


def reject_book(request,id):
    q=CourtBooking.objects.get(pk=id)
    q.status='rejected'
    q.save()
    return HttpResponse("<script>alert('Rejected');window.location='/manage_court';</script>")


def reject_tour_req(request,id):
    q=TournamentRequest.objects.get(pk=id)
    q.status='rejected'
    q.save()
    return HttpResponse("<script>alert('Rejected');window.location='/manage_tournament';</script>")
    
   




def membership_request(request,id):
    s = MembershipRequest.objects.filter(user_id=request.session['uid'], status__in=['pending', 'rejected'],court_id=id)
    
    f = MembershipRequest.objects.filter(user_id=request.session['uid'], status__in=['accepted'],court_id=id)
    
    
    if s:
        
        return HttpResponse("<script>alert('Already Requested');window.location='/user_view_court';</script>")
    
    elif f:
        
        return HttpResponse("<script>alert('You are Member');window.location='/user_view_court';</script>")
        
    
    else:
        
        d=MembershipRequest(date=datetime.now().date(),court_id=id,user_id=request.session['uid'],status='pending')
        d.save()
        return HttpResponse("<script>alert('Requested successfully');window.location='/user_view_court';</script>")
    
    
    


from django.http import HttpResponse
from datetime import datetime
from .models import MembershipRequest, TournamentRequest

def req_for_tournament(request, id, ids):
    user_id = request.session.get('uid')
    
    # Check if the user has a membership for the court
    has_membership = MembershipRequest.objects.filter(court_id=ids, status='accepted').exists()
    
    if not has_membership:
        return HttpResponse("<script>alert('You Don't Have The Membership');window.location='/user_view_court';</script>")
    
    # Check if the user has already requested for the tournament
    already_requested = TournamentRequest.objects.filter(user_id=user_id, tournament_id=id).exists()
    
    if already_requested:
        return HttpResponse("<script>alert('Already Requested or Rejected');window.location='/user_view_court';</script>")
    
    # If user has membership and has not already requested, create a new request
    new_request = TournamentRequest(date=datetime.now().date(), tournament_id=id, user_id=user_id, status='pending')
    new_request.save()
    
    return HttpResponse("<script>alert('Request Submitted Successfully');window.location='/user_view_court';</script>")

    
    
    
  
        
        
    
  
    
   