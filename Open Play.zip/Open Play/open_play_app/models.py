from django.db import models
from django.contrib.auth.models import User

class Login(models.Model):
    login_id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    usertype = models.CharField(max_length=50)

class Prop(models.Model):
    prop_id = models.AutoField(primary_key=True)
    login = models.ForeignKey(Login, on_delete=models.CASCADE)
    prop_name = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    email = models.EmailField()

class User(models.Model):
    user_id = models.AutoField(primary_key=True)
    login = models.ForeignKey(Login, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    email = models.EmailField()

class Court(models.Model):
    court_id = models.AutoField(primary_key=True)
    prop = models.ForeignKey(Prop, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    status = models.CharField(max_length=50)

class RatingFeedback(models.Model):
    rating_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    court = models.ForeignKey(Court, on_delete=models.CASCADE)
    review = models.TextField()
    date = models.DateField()



class Tournament(models.Model):
    tournament_id = models.AutoField(primary_key=True)
    tournament_name = models.CharField(max_length=100)
    court = models.ForeignKey(Court, on_delete=models.CASCADE)
    description = models.TextField()
    status = models.CharField(max_length=50)

class TournamentRequest(models.Model):
    t_request_id = models.AutoField(primary_key=True)
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    status = models.CharField(max_length=50)
    date = models.DateField()

class Scheduling(models.Model):
    scheduling_id = models.AutoField(primary_key=True)
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    
    tournament_date = models.DateField()
    time = models.TimeField()

class Winner(models.Model):
    winner_id = models.AutoField(primary_key=True)
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    position = models.CharField(max_length=50)
    date = models.DateField()

class MembershipRequest(models.Model):
    m_request_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    court = models.ForeignKey(Court, on_delete=models.CASCADE)
    date = models.DateField()
    status = models.CharField(max_length=50)

class CourtBooking(models.Model):
    court_booking_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    court = models.ForeignKey(Court, on_delete=models.CASCADE)
    game_name = models.CharField(max_length=100)
    for_date = models.DateField()
    time = models.TimeField()
    date = models.DateField()
    status = models.CharField(max_length=50)

class CourtBookingStatus(models.Model):
    status_id = models.AutoField(primary_key=True)
    court_booking = models.ForeignKey(CourtBooking, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    status = models.CharField(max_length=50)
    

class Facilities(models.Model):
    facilities_id = models.AutoField(primary_key=True)
    court = models.ForeignKey(Court, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='static/')
    description = models.TextField()
    date = models.DateField()
