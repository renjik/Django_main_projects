"""care URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from .import views

urlpatterns = [
    

    
    path('',views.home),
    path('login',views.logins),
    
    
    
    
    

    path('adminhome',views.adminhome),
    
    path('admin_view_user',views.admin_view_user),
    
    path('review_court',views.review_court),
    
    
    path('add_facilities',views.add_facilities),
    
    
    
    
    path('view_reviews/<id>',views.view_reviews),
    
    
    
    
    path('prop_court/<id>',views.prop_court),
    
    
    path('court_review/<id>',views.court_review),
    
    
    path('block/<id>',views.block),
    
    path('unblock/<id>',views.unblock),
    
    
    
    
    
    
    
    
    
    

    
    path('prophome',views.prophome),
    
    path('manage_prop',views.manage_prop),
    
    path('manage_court',views.manage_court),
    
    
    path('manage_tournament',views.manage_tournament),
    
    
    path('facilities/<id>',views.add_facilities),
    
    
    
    path('user_view_facilities/<id>',views.user_view_facilities),
    
    
    path('update_profile/<id>',views.update_profile),
    
    
    
    
    path('send_feed/<id>',views.send_feedback),
    
    
    
    
    
    path('user_reg',views.register),
    
    
    path('profile',views.profile),
    
    
    path('user_view_court',views.user_view_court),
    
    
    path('membership_request/<id>',views.membership_request),
    
    path('view_membership_request/<id>',views.view_membership_request),
    
    
    
    path('accept_mr/<id>',views.accept_mr),
    
    
    path('reject_mr/<id>',views.reject_mr),
    
    path('accept_tour_req/<id>',views.accept_tour_req),
    
    path('accept_book/<id>',views.accept_book),
    
    path('reject_book/<id>',views.reject_book),
    
    
    
    
    path('reject_tour_req/<id>',views.reject_tour_req),
    
    
    path('accept_user/<id>',views.accept_user),
    
    path('reject_user/<id>',views.reject_user),
    
    
    path('bookings/<id>',views.bookings),
    
    
    
    
    
    
    
    path('schedule_tour/<id>',views.schedule_tour),
    
    
    path('winner_list/<id>',views.winner_list),
    
    path('user_view_tournament/<id>',views.user_view_tournament),
    
    path('view_schedule/<id>',views.view_schedule),
    
    path('view_winner/<id>',views.view_winner),
    
    path('user_book_court/<id>',views.user_book_court),
    
    path('user_view_booking',views.user_view_booking),
    
    path('other_booking',views.other_booking),
    
    
    
    path('user_request/<id>',views.user_request),
    
    
    path('send_request/<id>',views.send_request),
    
    path('recent_request/<id>',views.recent_request),
    
    
    
    
    
    
    
    
    path('user_view_tour_re',views.user_view_tour_re),
    
    
    path('user_view_schedule/<id>',views.user_view_schedule),
    
    
    path('user_view_winner/<id>',views.user_view_winner),
    
    
    
    
    path('tour_request/<id>',views.tour_request),
    
    
    
    path('req_for_tournament/<id>/<ids>',views.req_for_tournament),
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #//////////////////////////////////////User Function//////////////////////////
    
    path('userhome',views.userhome),
    

     
    ]
