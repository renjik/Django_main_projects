from django.apps import AppConfig


class OpenPlayAppConfig(AppConfig):
    name = 'open_play_app'
